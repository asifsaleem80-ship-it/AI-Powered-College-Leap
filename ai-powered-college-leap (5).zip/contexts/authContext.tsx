import React, { createContext, useState, useEffect, useCallback, ReactNode, useContext } from 'react';
import type { User, College } from '../types';
import { auth, isFirebaseConfigured } from '../services/firebase';
import { getFavorites, addFavorite, removeFavorite as removeFavoriteFromDb } from '../services/firestoreService';
// FIX: Switched to default firebase import and added 'firebase/compat/auth' to make `firebase.auth` available.
import firebase from 'firebase/compat/app';
import 'firebase/compat/auth';
import { ErrorContext } from './errorContext';
import { I18nContext } from './i18nContext';

// Extend the Window interface for google.accounts
declare global {
    interface Window {
        google: any;
    }
}

interface AuthContextType {
  user: User | null;
  logout: () => void;
  favorites: College[];
  addFavorite: (college: College) => Promise<void>;
  removeFavorite: (collegeId: string) => Promise<void>;
  isGsiReady: boolean;
}

export const AuthContext = createContext<AuthContextType | undefined>(undefined);

interface AuthProviderProps {
  children: ReactNode;
}

const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID;

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [favorites, setFavorites] = useState<College[]>([]);
  const [isGsiReady, setIsGsiReady] = useState(false);

  const errorContext = useContext(ErrorContext);
  const i18nContext = useContext(I18nContext);

  if (!errorContext || !i18nContext) {
    throw new Error("AuthProvider must be used within an ErrorProvider and I18nProvider");
  }
  const { setError } = errorContext;
  const { t } = i18nContext;

  const handleCredentialResponse = useCallback(async (response: any) => {
    if (!isFirebaseConfigured) return;
    const idToken = response.credential;
    const credential = firebase.auth.GoogleAuthProvider.credential(idToken);
    try {
        await auth.signInWithCredential(credential);
    } catch (error) {
        console.error("Firebase sign-in error:", error);
        setError(t.error.auth.signInError);
    }
  }, [setError, t]);

  const logout = useCallback(() => {
    if (!isFirebaseConfigured) return;
    auth.signOut();
    if (window.google) {
        window.google.accounts.id.disableAutoSelect();
    }
  }, []);
  
  const handleAddFavorite = async (college: College) => {
    if (!user) return;
    try {
        const docId = await addFavorite(user.uid, college);
        const newFavorite = { ...college, id: docId };
        setFavorites(prev => [...prev, newFavorite]);
    } catch (error) {
        console.error("Failed to add favorite:", error);
        setError(t.error.auth.addFavoriteError);
    }
  };

  const handleRemoveFavorite = async (collegeId: string) => {
    if (!user) return;
    try {
        await removeFavoriteFromDb(user.uid, collegeId);
        setFavorites(prev => prev.filter(fav => fav.id !== collegeId));
    } catch (error) {
        console.error("Failed to remove favorite:", error);
        setError(t.error.auth.removeFavoriteError);
    }
  };

  // Effect for Firebase Auth State
  useEffect(() => {
    if (!isFirebaseConfigured) {
        setLoading(false);
        return;
    }
    const unsubscribe = auth.onAuthStateChanged(async (firebaseUser) => {
      if (firebaseUser) {
        const currentUser = {
          uid: firebaseUser.uid,
          name: firebaseUser.displayName || 'User',
          email: firebaseUser.email || '',
          picture: firebaseUser.photoURL || '',
        };
        setUser(currentUser);
        try {
            const userFavorites = await getFavorites(currentUser.uid);
            setFavorites(userFavorites);
        } catch {
            setError(t.error.auth.favoritesError);
        }
      } else {
        setUser(null);
        setFavorites([]);
      }
      setLoading(false);
    });
    
    return () => unsubscribe();
  }, [setError, t]);

  // Effect for GSI Script Loading and Initialization
  useEffect(() => {
    if (!GOOGLE_CLIENT_ID) {
        console.warn("Google Client ID is not configured. Login will be disabled.");
        return;
    }
    
    // If GSI is ready or the script is already on the page, don't add it again.
    if (isGsiReady || document.getElementById('google-gsi-script')) {
        return;
    }
    
    const script = document.createElement('script');
    script.id = 'google-gsi-script';
    script.src = 'https://accounts.google.com/gsi/client';
    script.async = true;
    script.defer = true;
    
    script.onload = () => {
      try {
        if (!window.google?.accounts?.id) {
          throw new Error("GSI script loaded but google.accounts.id not found.");
        }
        window.google.accounts.id.initialize({
          client_id: GOOGLE_CLIENT_ID,
          callback: handleCredentialResponse,
        });
        setIsGsiReady(true);
      } catch (error) {
        console.error("Error initializing GSI client:", error);
      }
    };
    
    script.onerror = () => {
      console.error("Failed to load Google GSI script.");
    };
    
    document.body.appendChild(script);

  }, [isGsiReady, handleCredentialResponse]);


  const value = { 
    user, 
    logout, 
    favorites,
    addFavorite: handleAddFavorite,
    removeFavorite: handleRemoveFavorite,
    isGsiReady,
  };

  return <AuthContext.Provider value={value}>{!loading && children}</AuthContext.Provider>;
};