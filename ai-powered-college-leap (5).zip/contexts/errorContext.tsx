import React, { createContext, useState, useCallback, ReactNode } from 'react';

interface ErrorState {
  id: number;
  message: string;
  onRetry?: () => void;
}

interface ErrorContextType {
  error: ErrorState | null;
  setError: (message: string, onRetry?: () => void) => void;
  clearError: () => void;
}

export const ErrorContext = createContext<ErrorContextType | undefined>(undefined);

interface ErrorProviderProps {
  children: ReactNode;
}

export const ErrorProvider: React.FC<ErrorProviderProps> = ({ children }) => {
  const [error, setErrorState] = useState<ErrorState | null>(null);

  const setError = useCallback((message: string, onRetry?: () => void) => {
    setErrorState({ id: Date.now(), message, onRetry });
  }, []);

  const clearError = useCallback(() => {
    setErrorState(null);
  }, []);

  const value = { error, setError, clearError };

  return (
    <ErrorContext.Provider value={value}>
      {children}
    </ErrorContext.Provider>
  );
};