import React, { createContext, useState, useMemo, useEffect } from 'react';
import { locales } from '../i18n/locales';

const RTL_LANGUAGES = ['ar', 'ur'];

interface I18nContextType {
  locale: string;
  setLocale: (locale: string) => void;
  t: any;
  dir: 'ltr' | 'rtl';
}

export const I18nContext = createContext<I18nContextType>({
  locale: 'en',
  setLocale: () => {},
  t: locales.en,
  dir: 'ltr',
});

interface I18nProviderProps {
  children: React.ReactNode;
}

export const I18nProvider: React.FC<I18nProviderProps> = ({ children }) => {
  const [locale, setLocale] = useState('en');

  // FIX: The type of `dir` was being inferred as a generic `string`, which is not assignable
  // to the context's expected type of `'ltr' | 'rtl'`. This has been corrected by explicitly
  // defining the type here and reusing the constant.
  const dir: 'ltr' | 'rtl' = RTL_LANGUAGES.includes(locale) ? 'rtl' : 'ltr';

  useEffect(() => {
    document.documentElement.dir = dir;
    document.documentElement.lang = locale;
  }, [locale, dir]);

  const value = useMemo(() => ({
    locale,
    setLocale,
    t: locales[locale] || locales.en,
    dir,
  }), [locale, dir]);

  return (
    <I18nContext.Provider value={value}>
      {children}
    </I18nContext.Provider>
  );
};