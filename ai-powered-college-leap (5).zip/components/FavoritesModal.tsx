import React from 'react';
import { Modal } from './Modal';
import { useAuth } from '../hooks/useAuth';
import { useI18n } from '../hooks/useI18n';
import { TrashIcon } from './icons';

interface FavoritesModalProps {
    isOpen: boolean;
    onClose: () => void;
}

export const FavoritesModal: React.FC<FavoritesModalProps> = ({ isOpen, onClose }) => {
    const { favorites, removeFavorite } = useAuth();
    const { t } = useI18n();
    
    return (
        <Modal isOpen={isOpen} onClose={onClose} title={t.favorites.title}>
            <div className="p-1 min-h-[200px] max-h-[60vh] overflow-y-auto">
                {favorites.length === 0 ? (
                    <p className="text-gray-400 text-center p-4">{t.favorites.empty}</p>
                ) : (
                    <ul className="space-y-3">
                        {favorites.map(college => (
                            <li key={college.id} className="flex items-center justify-between p-3 bg-slate-700/50 rounded-lg">
                                <div>
                                    <h3 className="font-semibold text-sky-400">{college.name}</h3>
                                    <a 
                                        href={college.website} 
                                        target="_blank" 
                                        rel="noopener noreferrer"
                                        className="text-xs text-gray-400 hover:text-cyan-300 transition-colors"
                                    >
                                        Visit Website &rarr;
                                    </a>
                                </div>
                                <button
                                    onClick={() => college.id && removeFavorite(college.id)}
                                    className="text-gray-400 hover:text-red-400 p-2 rounded-full transition-colors"
                                    aria-label={`${t.favorites.remove} ${college.name}`}
                                    title={t.favorites.remove}
                                >
                                    <TrashIcon className="w-5 h-5" />
                                </button>
                            </li>
                        ))}
                    </ul>
                )}
            </div>
        </Modal>
    );
};