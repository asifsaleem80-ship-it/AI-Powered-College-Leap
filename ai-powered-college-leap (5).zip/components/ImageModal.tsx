import React from 'react';
import { Modal } from './Modal';
import { useI18n } from '../hooks/useI18n';
import { DownloadIcon } from './icons';

interface ImageModalProps {
  isOpen: boolean;
  onClose: () => void;
  isLoading: boolean;
  imageUrl: string | null;
  error: string | null;
  studentName: string | undefined;
}

export const ImageModal: React.FC<ImageModalProps> = ({ 
    isOpen, 
    onClose, 
    isLoading, 
    imageUrl, 
    error, 
    studentName 
}) => {
    const { t } = useI18n();
    const modalTitle = t.imageModal.title.replace('{studentName}', studentName || 'your');

    const handleDownload = () => {
        if (!imageUrl) return;
        const link = document.createElement('a');
        link.href = `data:image/png;base64,${imageUrl}`;
        link.download = `time_cover_${studentName?.replace(/\s/g, '_') || 'student'}.png`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={modalTitle}>
            <div className="p-6 text-center min-h-[350px] flex flex-col justify-center items-center">
                {isLoading && (
                    <>
                        <div className="animate-spin rounded-full h-12 w-12 border-t-4 border-b-4 border-amber-500 mb-4"></div>
                        <p className="text-lg text-amber-300">{t.imageModal.loading}</p>
                    </>
                )}
                {error && !isLoading && (
                    <>
                        <p className="text-red-300 mb-4">{error}</p>
                        <button 
                            onClick={onClose} 
                            className="px-4 py-2 text-sm font-semibold bg-red-600 text-white rounded-md hover:bg-red-500 transition-colors"
                        >
                            {t.error.dismiss}
                        </button>
                    </>
                )}
                {imageUrl && !isLoading && (
                    <div className="space-y-4">
                        <img
                            src={`data:image/png;base64,${imageUrl}`}
                            alt={t.imageModal.alt.replace('{studentName}', studentName || 'student')}
                            className="w-full max-w-sm rounded-lg shadow-lg"
                        />
                         <button 
                            onClick={handleDownload} 
                            className="w-full flex items-center justify-center bg-amber-600 hover:bg-amber-500 text-white font-bold py-2 px-4 rounded-lg transition-colors">
                            <DownloadIcon className="w-5 h-5 mr-2 rtl:ml-2 rtl:mr-0" />
                            {t.imageModal.downloadButton}
                        </button>
                    </div>
                )}
            </div>
        </Modal>
    );
};