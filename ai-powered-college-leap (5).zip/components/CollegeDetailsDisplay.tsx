import React, { useState, useCallback, useRef, useEffect } from 'react';
import type { CollegeDetails, ChatMessage } from '../types';
import { useI18n } from '../hooks/useI18n';
import { 
    SendIcon, 
    InformationCircleIcon,
    GraduationCapIcon,
    UsersIcon,
    SparklesIcon,
} from './icons';
import { askAboutCollege } from '../services/geminiService';

interface CollegeDetailsDisplayProps {
    collegeName: string;
    studentSummary: string;
    languageName: string;
    isLoadingDetails: boolean;
    details: CollegeDetails | null;
}

const DetailSection: React.FC<{ title: string; children: React.ReactNode; className?: string }> = ({ title, children, className = '' }) => (
    <div className={className}>
        <h3 className="text-2xl font-bold text-fuchsia-300 mb-4">{title}</h3>
        <div className="text-gray-300 text-sm space-y-4">{children}</div>
    </div>
);

const AccordionItem: React.FC<{ title: string; icon: React.ReactNode; children: React.ReactNode; startOpen?: boolean }> = ({ title, icon, children, startOpen = false }) => {
    const [isOpen, setIsOpen] = useState(startOpen);
    return (
        <div className="border-b border-white/10">
            <button 
                onClick={() => setIsOpen(!isOpen)} 
                className="w-full flex justify-between items-center text-left rtl:text-right py-4 px-2"
                aria-expanded={isOpen}
            >
                <div className="flex items-center gap-3">
                    <span className="text-fuchsia-400">{icon}</span>
                    <span className="text-lg font-semibold text-gray-200">{title}</span>
                </div>
                <span className="text-gray-400 text-2xl font-light w-6 text-center" aria-hidden="true">{isOpen ? '−' : '+'}</span>
            </button>
            {isOpen && (
                <div className="pb-4 px-2 text-gray-300">
                    {children}
                </div>
            )}
        </div>
    )
};

const TypingIndicator: React.FC = () => (
    <div className="flex items-center space-x-1">
        <div className="w-1.5 h-1.5 bg-fuchsia-400 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
        <div className="w-1.5 h-1.5 bg-fuchsia-400 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
        <div className="w-1.5 h-1.5 bg-fuchsia-400 rounded-full animate-bounce"></div>
    </div>
);

export const CollegeDetailsDisplay: React.FC<CollegeDetailsDisplayProps> = ({
    collegeName,
    studentSummary,
    languageName,
    isLoadingDetails,
    details,
}) => {
    const { t } = useI18n();
    const [miniChatMessages, setMiniChatMessages] = useState<ChatMessage[]>([]);
    const [miniChatInput, setMiniChatInput] = useState('');
    const [isMiniChatLoading, setIsMiniChatLoading] = useState(false);
    const chatEndRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [miniChatMessages, isMiniChatLoading]);

    const handleSendMiniChatMessage = useCallback(async (e: React.FormEvent) => {
        e.preventDefault();
        if (!miniChatInput.trim() || !details) return;

        const question = miniChatInput;
        setMiniChatMessages(prev => [...prev, { role: 'user', message: question }]);
        setMiniChatInput('');
        setIsMiniChatLoading(true);

        try {
            const answer = await askAboutCollege(collegeName, details, studentSummary, question, languageName);
            setMiniChatMessages(prev => [...prev, { role: 'model', message: answer }]);
        } catch (err) {
            console.error("Mini-chat error:", err);
            setMiniChatMessages(prev => [...prev, { role: 'model', message: t.collegeCard.collegeChat.error }]);
        } finally {
            setIsMiniChatLoading(false);
        }
    }, [miniChatInput, details, collegeName, studentSummary, languageName, t]);

    if (isLoadingDetails) {
        return (
            <div className="space-y-8 animate-pulse">
                <div className="aspect-[16/10] bg-white/10 rounded-lg w-full"></div>
                <div className="flex gap-4">
                    <div className="h-16 bg-white/10 rounded-lg w-1/2"></div>
                    <div className="h-16 bg-white/10 rounded-lg w-1/2"></div>
                </div>
                <div className="space-y-4">
                    <div className="h-8 bg-white/10 rounded w-full"></div>
                    <div className="h-8 bg-white/10 rounded w-full"></div>
                    <div className="h-8 bg-white/10 rounded w-full"></div>
                </div>
            </div>
        );
    }

    if (!details) {
        return null; 
    }

    return (
        <div className="space-y-10">
            {(details.averageGpa || details.acceptanceRate) && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {details.averageGpa && (
                        <div className="bg-black/20 backdrop-blur-lg p-4 rounded-lg text-center border border-white/10">
                            <div className="text-sm text-gray-400 mb-1">{t.collegeCard.avgGpa}</div>
                            <div className="text-2xl font-bold text-fuchsia-400">{details.averageGpa}</div>
                        </div>
                    )}
                    {details.acceptanceRate && (
                        <div className="bg-black/20 backdrop-blur-lg p-4 rounded-lg text-center border border-white/10">
                            <div className="text-sm text-gray-400 mb-1">{t.collegeCard.acceptanceRate}</div>
                            <div className="text-2xl font-bold text-fuchsia-400">{details.acceptanceRate}</div>
                        </div>
                    )}
                </div>
            )}
            
            <div className="space-y-2">
                <AccordionItem title={t.collegeCard.overview} icon={<InformationCircleIcon />} startOpen={true}>
                    <p className="whitespace-pre-wrap">{details.overview}</p>
                </AccordionItem>
                <AccordionItem title={t.collegeCard.programHighlights} icon={<GraduationCapIcon />}>
                    <p className="whitespace-pre-wrap">{details.programHighlights}</p>
                </AccordionItem>
                <AccordionItem title={t.collegeCard.diversityAndCulture} icon={<UsersIcon />}>
                     <p className="whitespace-pre-wrap">{details.diversityAndCulture}</p>
                </AccordionItem>
                 <AccordionItem title={t.collegeCard.studentExperience} icon={<SparklesIcon />}>
                    <p className="whitespace-pre-wrap">{details.studentExperience}</p>
                </AccordionItem>
            </div>
            
            <DetailSection title={t.collegeCard.studentTestimonials}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {details.testimonials.map((testimonial, index) => (
                    <blockquote key={index} className="bg-black/20 backdrop-blur-lg p-4 rounded-lg border-l-4 rtl:border-l-0 rtl:border-r-4 border-fuchsia-500 italic">
                        <p>"{testimonial.quote}"</p>
                        <footer className="text-sm text-gray-400 mt-2 not-italic font-semibold">- {testimonial.author}</footer>
                    </blockquote>
                ))}
                </div>
            </DetailSection>

            <DetailSection title={t.collegeCard.collegeChat.title.replace('{collegeName}', collegeName)} className="pt-6 border-t border-white/10">
                <div className="bg-black/20 backdrop-blur-lg border border-white/10 rounded-lg p-3 flex flex-col h-72">
                    <div className="flex-1 overflow-y-auto space-y-3 pr-2 rtl:pr-0 rtl:pl-2 text-sm">
                        {miniChatMessages.map((msg, index) => (
                                <div key={index} className={`flex items-start gap-2 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                                <div className={`max-w-[85%] px-3 py-2 rounded-lg ${msg.role === 'user' ? 'bg-purple-700 text-white' : 'bg-slate-600 text-gray-200'}`}>
                                    <p className="whitespace-pre-wrap">{msg.message}</p>
                                </div>
                            </div>
                        ))}
                        {isMiniChatLoading && (
                            <div className="flex justify-start">
                                <div className="bg-slate-600 px-3 py-1.5 rounded-lg">
                                    <TypingIndicator />
                                </div>
                            </div>
                        )}
                        <div ref={chatEndRef}></div>
                    </div>
                    <form onSubmit={handleSendMiniChatMessage} className="mt-2 flex items-center space-x-2 rtl:space-x-reverse border-t border-white/10 pt-3">
                        <input
                            type="text"
                            value={miniChatInput}
                            onChange={(e) => setMiniChatInput(e.target.value)}
                            placeholder={t.collegeCard.collegeChat.placeholder}
                            className="flex-1 bg-slate-700 border border-slate-600 rounded-full px-4 py-2 text-white text-sm focus:ring-fuchsia-500 focus:border-fuchsia-500"
                            disabled={isMiniChatLoading}
                        />
                        <button
                            type="submit"
                            disabled={isMiniChatLoading || !miniChatInput.trim()}
                            className="bg-purple-600 hover:bg-purple-500 disabled:bg-gray-500 text-white rounded-full p-3 transition-colors"
                            aria-label={t.collegeCard.collegeChat.sendButton}
                        >
                            <SendIcon className="w-5 h-5" />
                        </button>
                    </form>
                </div>
            </DetailSection>
        </div>
    );
};