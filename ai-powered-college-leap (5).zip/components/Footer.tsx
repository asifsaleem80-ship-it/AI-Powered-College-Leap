import React, { memo } from 'react';
import { useI18n } from '../hooks/useI18n';
import { GlobeAltIcon, DevicePhoneMobileIcon, ChipIcon, AccessibilityIcon } from './icons';

export const Footer: React.FC = memo(() => {
    const { t } = useI18n();
    const currentYear = new Date().getFullYear();

    const compatibilitySections = [
        {
            icon: <GlobeAltIcon className="w-8 h-8 mx-auto mb-3 text-fuchsia-400" />,
            title: t.footer.browsers,
            items: ['Chrome', 'Firefox', 'Safari', 'Edge']
        },
        {
            icon: <DevicePhoneMobileIcon className="w-8 h-8 mx-auto mb-3 text-fuchsia-400" />,
            title: t.footer.devices,
            items: ['Desktop', 'Tablet', 'Mobile']
        },
        {
            icon: <ChipIcon className="w-8 h-8 mx-auto mb-3 text-fuchsia-400" />,
            title: t.footer.os,
            items: ['Windows & macOS', 'iOS & Android']
        },
        {
            icon: <AccessibilityIcon className="w-8 h-8 mx-auto mb-3 text-fuchsia-400" />,
            title: t.footer.accessibility,
            items: ['Screen Readers', 'Keyboard Navigation', 'Voice Control']
        }
    ];

    return (
        <footer className="bg-slate-900/50 border-t border-white/10 mt-16 sm:mt-24 py-12 sm:py-16">
            <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
                <h2 className="text-center text-2xl sm:text-3xl font-bold text-fuchsia-400 mb-8 sm:mb-12">
                    {t.footer.title}
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 text-center">
                    {compatibilitySections.map(section => (
                        <div key={section.title}>
                            {section.icon}
                            <h3 className="font-semibold text-gray-200">{section.title}</h3>
                            <ul className="mt-2 space-y-1 text-sm text-gray-400">
                                {section.items.map(item => <li key={item}>{item}</li>)}
                            </ul>
                        </div>
                    ))}
                </div>
                <div className="mt-12 sm:mt-16 pt-8 border-t border-white/10 text-center text-sm text-gray-500">
                    <p>{t.footer.copyright.replace('{year}', currentYear.toString())}</p>
                </div>
            </div>
        </footer>
    );
});