import React, { useState, useRef, useEffect } from 'react';
import { useI18n } from '../hooks/useI18n';
import { ShareIcon, TwitterIcon, FacebookIcon, LinkedInIcon, LinkIcon, CheckCircleIcon } from './icons';

interface ShareDropdownProps {
    shareText: string;
    shareTitle: string;
    isSmall?: boolean;
}

export const ShareDropdown: React.FC<ShareDropdownProps> = ({ shareText, shareTitle, isSmall = false }) => {
    const { t } = useI18n();
    const [isOpen, setIsOpen] = useState(false);
    const [copied, setCopied] = useState(false);
    const dropdownRef = useRef<HTMLDivElement>(null);

    const appUrl = window.location.href;
    const encodedUrl = encodeURIComponent(appUrl);
    const encodedText = encodeURIComponent(shareText);
    const encodedTitle = encodeURIComponent(shareTitle);

    const shareLinks = {
        twitter: `https://twitter.com/intent/tweet?url=${encodedUrl}&text=${encodedText}`,
        facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`,
        linkedin: `https://www.linkedin.com/shareArticle?mini=true&url=${encodedUrl}&title=${encodedTitle}&summary=${encodedText}`,
    };

    const handleCopy = () => {
        navigator.clipboard.writeText(`${shareText}\n\n${appUrl}`).then(() => {
            setCopied(true);
            setTimeout(() => {
                setCopied(false);
                setIsOpen(false);
            }, 1500);
        });
    };

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
                setIsOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, []);

    const buttonClass = isSmall 
        ? "p-2 text-gray-400 hover:bg-white/10 rounded-full" 
        : "p-3 rounded-full bg-slate-800/60 backdrop-blur-sm border border-white/10 text-gray-400 shadow-lg hover:bg-gray-700/80 hover:border-gray-500/50 hover:scale-110 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-gray-500 transition-all duration-300";

    const iconClass = isSmall ? "w-5 h-5" : "w-6 h-6";

    return (
        <div className="relative" ref={dropdownRef}>
            <button
                onClick={() => setIsOpen(!isOpen)}
                aria-label={t.share.title}
                title={t.share.title}
                className={buttonClass}
            >
                <ShareIcon className={iconClass} />
            </button>
            {isOpen && (
                <div className="absolute right-0 bottom-full mb-2 w-48 bg-slate-800/90 backdrop-blur-lg border border-white/10 rounded-lg shadow-2xl z-20 py-1 transition-all duration-300 origin-bottom-right animate-fade-in-up">
                    <a href={shareLinks.twitter} target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 px-4 py-2 text-sm text-gray-300 hover:bg-white/10">
                        <TwitterIcon className="w-5 h-5" /> {t.share.twitter}
                    </a>
                    <a href={shareLinks.facebook} target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 px-4 py-2 text-sm text-gray-300 hover:bg-white/10">
                        <FacebookIcon className="w-5 h-5" /> {t.share.facebook}
                    </a>
                    <a href={shareLinks.linkedin} target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 px-4 py-2 text-sm text-gray-300 hover:bg-white/10">
                        <LinkedInIcon className="w-5 h-5" /> {t.share.linkedin}
                    </a>
                    <button onClick={handleCopy} className="w-full text-left flex items-center gap-3 px-4 py-2 text-sm text-gray-300 hover:bg-white/10">
                        {copied ? <CheckCircleIcon className="w-5 h-5 text-green-400" /> : <LinkIcon className="w-5 h-5" />}
                        {copied ? t.share.copied : t.share.copyLink}
                    </button>
                </div>
            )}
            <style>{`
                @keyframes fade-in-up {
                    from { opacity: 0; transform: translateY(10px) scale(0.95); }
                    to { opacity: 1; transform: translateY(0) scale(1); }
                }
                .animate-fade-in-up {
                    animation: fade-in-up 0.2s ease-out forwards;
                }
            `}</style>
        </div>
    );
};