import React, { useState, useEffect, useCallback, memo } from 'react';
import { SparklesIcon, PlayIcon, PauseIcon, StopIcon, ChatBubbleIcon, CheckCircleIcon, VideoCameraIcon, CameraIcon } from './icons';
import { useI18n } from '../hooks/useI18n';
import { ShareDropdown } from './ShareDropdown';
import type { StudentAnalysis, FileData } from '../types';
import { generateSummaryVideo, generateCoverImage } from '../services/geminiService';
import { VideoModal } from './VideoModal';
import { ImageModal } from './ImageModal';

// FIX: Moved AIStudio type definition to types.ts to centralize global type declarations and resolve "Subsequent property declarations must have the same type" error.
interface SummaryCardProps {
  analysis: StudentAnalysis;
  studentPicture: FileData | null;
  onStartChat: () => void;
  locale: string;
}

export const SummaryCard: React.FC<SummaryCardProps> = memo(({ analysis, studentPicture, onStartChat, locale }) => {
  const { t } = useI18n();
  const { summary, keyStrengths } = analysis;
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  
  const utteranceRef = React.useRef<SpeechSynthesisUtterance | null>(null);

  // State for Video Generation
  const [isVideoModalOpen, setIsVideoModalOpen] = useState(false);
  const [isGeneratingVideo, setIsGeneratingVideo] = useState(false);
  const [videoGenerationProgress, setVideoGenerationProgress] = useState('');
  const [generatedVideoUrl, setGeneratedVideoUrl] = useState<string | null>(null);
  const [videoError, setVideoError] = useState<string | null>(null);

  // State for Image Generation
  const [isImageModalOpen, setIsImageModalOpen] = useState(false);
  const [isGeneratingImage, setIsGeneratingImage] = useState(false);
  const [generatedImageUrl, setGeneratedImageUrl] = useState<string | null>(null);
  const [imageError, setImageError] = useState<string | null>(null);


  // Get available voices from the browser
  useEffect(() => {
    const synth = window.speechSynthesis;
    const updateVoices = () => {
        setVoices(synth.getVoices());
    };
    
    // Voices are loaded asynchronously
    synth.addEventListener('voiceschanged', updateVoices);
    updateVoices(); // Call it once in case they are already loaded

    return () => {
        synth.removeEventListener('voiceschanged', updateVoices);
    };
  }, []);

  const handleStop = useCallback(() => {
    // Check if synthesis is active before trying to cancel
    if (window.speechSynthesis.speaking || window.speechSynthesis.pending) {
        window.speechSynthesis.cancel();
    }
    setIsSpeaking(false);
    setIsPaused(false);
  }, []);
  
  // Create and configure the utterance when summary, locale, or voices change
  useEffect(() => {
    const synth = window.speechSynthesis;
    
    // Make sure to stop any ongoing speech before creating a new one
    if (synth.speaking || synth.pending) {
        synth.cancel();
    }
    
    const utterance = new SpeechSynthesisUtterance(summary);
    utterance.lang = locale;
    utterance.onend = () => {
      setIsSpeaking(false);
      setIsPaused(false);
    };

    if (voices.length > 0) {
        const lang = locale.split('-')[0];

        // --- Voice Selection Logic ---
        // 1. Try to find a high-quality, female-sounding voice for the specific locale (e.g., 'en-US')
        let selectedVoice = voices.find(voice => 
            voice.lang === locale && /Samantha|Zira|Google US English/i.test(voice.name)
        );

        // 2. Fallback to any voice marked as 'Female' for the specific locale
        if (!selectedVoice) {
            selectedVoice = voices.find(voice => 
                voice.lang === locale && /female/i.test(voice.name)
            );
        }
        
        // 3. Fallback to any 'Female' voice for the general language (e.g., 'en')
        if (!selectedVoice) {
            selectedVoice = voices.find(voice => 
                voice.lang.startsWith(lang) && /female/i.test(voice.name)
            );
        }

        // 4. As a last resort for female voices, check for common female names for the language
        if (!selectedVoice) {
            const femaleNames = /Samantha|Karen|Victoria|Zira|Susan|Tessa/i;
            selectedVoice = voices.find(voice => 
                voice.lang.startsWith(lang) && femaleNames.test(voice.name)
            );
        }
        
        // 5. If a suitable female voice is found, assign it
        if (selectedVoice) {
            utterance.voice = selectedVoice;
        }
    }

    utteranceRef.current = utterance;

    return () => {
      // Cleanup: stop speaking if the component unmounts or dependencies change
      handleStop();
    };
  }, [summary, locale, voices, handleStop]);
  
  const handlePlay = () => {
    if (!utteranceRef.current) return;

    if (isPaused) {
      window.speechSynthesis.resume();
      setIsPaused(false);
    } else {
        // Stop any previous speech before starting a new one
        if (window.speechSynthesis.speaking) {
            window.speechSynthesis.cancel();
        }
        window.speechSynthesis.speak(utteranceRef.current);
    }
    setIsSpeaking(true);
  };
  
  const handlePause = () => {
    window.speechSynthesis.pause();
    setIsPaused(true);
  };
  
  const handleProgressCallback = useCallback((progressKey: 'initializing' | 'generating' | 'finalizing') => {
        const message = t.videoModal.loading[progressKey] || 'Loading...';
        setVideoGenerationProgress(message);
    }, [t]);

    const generateVideo = useCallback(async () => {
        setIsGeneratingVideo(true);
        setVideoGenerationProgress(t.videoModal.loading.initializing);

        try {
            const videoBlobUrl = await generateSummaryVideo(
                analysis.studentName || 'the student',
                analysis.summary,
                handleProgressCallback
            );
            setGeneratedVideoUrl(videoBlobUrl);
        } catch (err: any) {
            console.error("Video generation failed:", err);
            let errorMessage = t.videoModal.error.generationFailed;
            if (err.message?.includes('Requested entity was not found')) {
                errorMessage += ' ' + t.videoModal.error.apiKey;
            }
            setVideoError(errorMessage);
        } finally {
            setIsGeneratingVideo(false);
        }
    }, [analysis.studentName, analysis.summary, handleProgressCallback, t.videoModal.error]);

    const handleGenerateVideoClick = async () => {
        setGeneratedVideoUrl(null);
        setVideoError(null);
        setIsVideoModalOpen(true);
        
        if (!window.aistudio) {
            setVideoError("The AI Studio environment is not available.");
            setIsGeneratingVideo(false);
            return;
        }

        const hasKey = await window.aistudio.hasSelectedApiKey();
        if (!hasKey) {
            await window.aistudio.openSelectKey();
        }
        
        // Per guidance, assume key is selected after openSelectKey and proceed.
        generateVideo();
    };

    const handleVideoModalClose = () => {
        setIsVideoModalOpen(false);
        if (generatedVideoUrl) {
            URL.revokeObjectURL(generatedVideoUrl);
            setGeneratedVideoUrl(null);
        }
        setVideoError(null);
        setIsGeneratingVideo(false);
    };
    
    const handleGenerateImageClick = async () => {
        setGeneratedImageUrl(null);
        setImageError(null);
        setIsImageModalOpen(true);
        setIsGeneratingImage(true);

        try {
            const base64Image = await generateCoverImage(analysis.studentName || 'A Future Leader');
            setGeneratedImageUrl(base64Image);
        } catch (err: any) {
            console.error("Image generation failed:", err);
            setImageError(t.imageModal.error.generationFailed);
        } finally {
            setIsGeneratingImage(false);
        }
    };

    const handleImageModalClose = () => {
        setIsImageModalOpen(false);
        setGeneratedImageUrl(null);
        setImageError(null);
        setIsGeneratingImage(false);
    };


  const shareText = `${t.share.analysisPrefix}\n\n"${summary.substring(0, 150)}..."\n\n${t.share.checkOut}`;

  return (
    <>
        <div className="bg-gradient-to-br from-gray-900/30 to-purple-900/10 backdrop-blur-xl border border-fuchsia-500/20 rounded-2xl p-6 shadow-2xl shadow-purple-500/10 relative overflow-hidden">
            <div className="flex items-center mb-4 gap-4">
                {studentPicture ? (
                    <img src={`data:${studentPicture.mimeType};base64,${studentPicture.base64}`} alt={t.summaryCard.studentAvatarAlt} className="w-16 h-16 rounded-full object-cover border-2 border-fuchsia-500" />
                ) : (
                    <SparklesIcon className="w-8 h-8 text-fuchsia-400 mr-3 rtl:ml-3 rtl:mr-0 flex-shrink-0" />
                )}
                <h3 className="text-xl font-bold text-fuchsia-400">{t.summaryCard.title}</h3>
            </div>
          
            <div className="grid grid-cols-1 lg:grid-cols-5 gap-6 items-start">
                 <div className="lg:col-span-3">
                    <p className="text-gray-300 whitespace-pre-wrap">{summary}</p>
                </div>
                
                {keyStrengths && keyStrengths.length > 0 && (
                    <div className="lg:col-span-2 bg-slate-800/40 p-4 rounded-xl border border-fuchsia-500/10">
                        <h4 className="text-lg font-semibold text-fuchsia-300 mb-3">{t.summaryCard.keyStrengths}</h4>
                        <ul className="space-y-2">
                            {keyStrengths.map((strength, index) => (
                                <li key={index} className="flex items-start gap-2">
                                    <CheckCircleIcon className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                                    <span className="text-gray-300 text-sm">{strength}</span>
                                </li>
                            ))}
                        </ul>
                    </div>
                )}
            </div>

            <div className="mt-6 pt-4 border-t border-fuchsia-500/20 flex items-center justify-between flex-wrap gap-2">
                <div className="flex items-center gap-2">
                    {!isSpeaking ? (
                        <button 
                            onClick={handlePlay} 
                            aria-label={t.summaryCard.playButton} 
                            title={t.summaryCard.playButton}
                            className="p-3 rounded-full bg-slate-800/60 backdrop-blur-sm border border-white/10 text-fuchsia-400 shadow-lg hover:bg-fuchsia-900/50 hover:border-fuchsia-500/50 hover:scale-110 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-fuchsia-500 transition-all duration-300"
                        >
                            <PlayIcon />
                        </button>
                    ) : (
                        <div className="flex items-center gap-2">
                            <button 
                                onClick={isPaused ? handlePlay : handlePause} 
                                aria-label={isPaused ? t.summaryCard.resumeButton : t.summaryCard.pauseButton}
                                title={isPaused ? t.summaryCard.resumeButton : t.summaryCard.pauseButton}
                                className="p-3 rounded-full bg-slate-800/60 backdrop-blur-sm border border-white/10 text-fuchsia-400 shadow-lg hover:bg-fuchsia-900/50 hover:border-fuchsia-500/50 hover:scale-110 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-fuchsia-500 transition-all duration-300"
                            >
                                {isPaused ? <PlayIcon /> : <PauseIcon />}
                            </button>
                            <button 
                                onClick={handleStop} 
                                aria-label={t.summaryCard.stopButton}
                                title={t.summaryCard.stopButton}
                                className="p-3 rounded-full bg-slate-800/60 backdrop-blur-sm border border-white/10 text-red-400 shadow-lg hover:bg-red-900/50 hover:border-red-500/50 hover:scale-110 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-red-500 transition-all duration-300"
                            >
                                <StopIcon />
                            </button>
                        </div>
                    )}
                    <button
                        onClick={handleGenerateVideoClick}
                        disabled={isGeneratingVideo}
                        aria-label={t.summaryCard.videoButton}
                        title={t.summaryCard.videoButton}
                        className="p-3 rounded-full bg-slate-800/60 backdrop-blur-sm border border-white/10 text-cyan-400 shadow-lg hover:bg-cyan-900/50 hover:border-cyan-500/50 hover:scale-110 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-cyan-500 transition-all duration-300 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                        <VideoCameraIcon />
                    </button>
                    <button
                        onClick={handleGenerateImageClick}
                        disabled={isGeneratingImage}
                        aria-label={t.summaryCard.imageButton}
                        title={t.summaryCard.imageButton}
                        className="p-3 rounded-full bg-slate-800/60 backdrop-blur-sm border border-white/10 text-amber-400 shadow-lg hover:bg-amber-900/50 hover:border-amber-500/50 hover:scale-110 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-amber-500 transition-all duration-300 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                        <CameraIcon />
                    </button>
                </div>
                <div className="flex items-center gap-2">
                    <button 
                        onClick={onStartChat} 
                        aria-label={t.summaryCard.chatButton} 
                        title={t.summaryCard.chatButton} 
                        className="p-3 rounded-full bg-slate-800/60 backdrop-blur-sm border border-white/10 text-purple-400 shadow-lg hover:bg-purple-900/50 hover:border-purple-500/50 hover:scale-110 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-purple-500 transition-all duration-300"
                    >
                        <ChatBubbleIcon />
                    </button>
                    <ShareDropdown
                        shareText={shareText}
                        shareTitle={t.share.analysisTitle}
                    />
                </div>
            </div>

            <div className="absolute bottom-2 right-3 text-xs font-mono text-purple-700">
                {t.summaryCard.geminiPro}
            </div>
        </div>
        
        <VideoModal 
            isOpen={isVideoModalOpen}
            onClose={handleVideoModalClose}
            isLoading={isGeneratingVideo}
            progressText={videoGenerationProgress}
            videoUrl={generatedVideoUrl}
            error={videoError}
            onRetry={generateVideo}
            studentName={analysis.studentName}
        />

        <ImageModal
            isOpen={isImageModalOpen}
            onClose={handleImageModalClose}
            isLoading={isGeneratingImage}
            imageUrl={generatedImageUrl}
            error={imageError}
            studentName={analysis.studentName}
        />
    </>
  );
});