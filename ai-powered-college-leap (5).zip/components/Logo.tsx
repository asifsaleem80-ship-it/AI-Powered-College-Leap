import React, { memo } from 'react';

export const Logo: React.FC = memo(() => (
  <a href="/" aria-label="College Leap Home" className="flex items-center gap-3 focus:outline-none focus-visible:ring-2 focus-visible:ring-fuchsia-500 rounded-lg p-1 transition-transform transform hover:scale-105">
    <svg width="40" height="40" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
        <path d="M12 3L2 8L12 13L22 8L12 3Z" className="fill-fuchsia-500" />
        <path d="M2 8V16L12 21L22 16V8L12 13L2 8Z" className="fill-purple-600" />
    </svg>
    <span className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-fuchsia-400 to-pink-400 hidden sm:block">
      College Leap
    </span>
  </a>
));