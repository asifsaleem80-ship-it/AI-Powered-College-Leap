import React from 'react';
import { Modal } from './Modal';
import { useI18n } from '../hooks/useI18n';

interface VideoModalProps {
  isOpen: boolean;
  onClose: () => void;
  isLoading: boolean;
  progressText: string;
  videoUrl: string | null;
  error: string | null;
  onRetry: () => void;
  studentName: string | undefined;
}

export const VideoModal: React.FC<VideoModalProps> = ({ 
    isOpen, 
    onClose, 
    isLoading, 
    progressText, 
    videoUrl, 
    error, 
    onRetry,
    studentName 
}) => {
    const { t } = useI18n();
    const modalTitle = t.videoModal.title.replace('{studentName}', studentName || 'your');

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={modalTitle}>
            <div className="p-6 text-center min-h-[350px] flex flex-col justify-center items-center">
                {isLoading && (
                    <>
                        <div className="animate-spin rounded-full h-12 w-12 border-t-4 border-b-4 border-fuchsia-500 mb-4"></div>
                        <p className="text-lg text-fuchsia-300">{progressText}</p>
                        <p className="text-sm text-gray-400 mt-2 max-w-sm">{t.videoModal.loading.patience}</p>
                    </>
                )}
                {error && !isLoading && (
                    <>
                        <p className="text-red-300 mb-4">{error}</p>
                         <p className="text-sm text-gray-400 mt-2 max-w-sm mb-4">
                            For video generation, an API key with access to the Veo model is required. Please ensure you have selected one. 
                            <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" rel="noopener noreferrer" className="text-cyan-400 underline hover:text-cyan-300"> Learn more about billing.</a>
                        </p>
                        <button 
                            onClick={onRetry} 
                            className="px-4 py-2 text-sm font-semibold bg-red-600 text-white rounded-md hover:bg-red-500 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-red-500"
                        >
                            {t.error.tryAgain}
                        </button>
                    </>
                )}
                {videoUrl && !isLoading && (
                    <video
                        src={videoUrl}
                        controls
                        autoPlay
                        className="w-full max-w-full rounded-lg aspect-video"
                    >
                        {t.videoModal.unsupported}
                    </video>
                )}
            </div>
        </Modal>
    );
};