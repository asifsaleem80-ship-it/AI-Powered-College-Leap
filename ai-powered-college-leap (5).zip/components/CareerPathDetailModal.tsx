import React from 'react';
import { Modal } from './Modal';
import { useI18n } from '../hooks/useI18n';
import type { CareerPathDetails } from '../types';
import { BriefcaseIcon, CheckCircleIcon, TrendingUpIcon } from './icons';

const DetailSection: React.FC<{ icon: React.ReactNode, title: string, children: React.ReactNode }> = ({ icon, title, children }) => (
    <div>
        <h3 className="flex items-center gap-3 text-lg font-semibold text-cyan-400 mb-3">
            {icon}
            <span>{title}</span>
        </h3>
        {children}
    </div>
);


interface CareerPathDetailModalProps {
    isOpen: boolean;
    onClose: () => void;
    careerTitle: string;
    details: CareerPathDetails | null;
    isLoading: boolean;
    error: string | null;
    onRetry: () => void;
}

const Loader: React.FC<{text: string}> = ({ text }) => (
    <div className="flex flex-col items-center justify-center space-y-3 p-8">
        <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-cyan-500"></div>
        <p className="text-gray-300">{text}</p>
    </div>
);

export const CareerPathDetailModal: React.FC<CareerPathDetailModalProps> = ({ isOpen, onClose, careerTitle, details, isLoading, error, onRetry }) => {
    const { t } = useI18n();

    // The modal's title is now passed to the generic Modal component.
    // The main title within the content is now the career path title itself.
    const modalTitle = t.career.detailsModal.title.replace('{careerTitle}', careerTitle);
    
    return (
        <Modal isOpen={isOpen} onClose={onClose} title={modalTitle}>
            <div className="p-6 bg-slate-800 text-gray-200 min-h-[300px]">
                {isLoading && <Loader text={t.career.detailsModal.loading} />}
                
                {error && !isLoading && (
                    <div className="text-center p-8">
                        <p className="text-red-400 mb-4">{error}</p>
                        <button 
                            onClick={onRetry}
                            className="bg-cyan-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-cyan-500 transition-colors"
                        >
                            {t.error.tryAgain}
                        </button>
                    </div>
                )}
                
                {details && !isLoading && (
                    <div className="space-y-6">
                        <DetailSection icon={<BriefcaseIcon className="w-6 h-6" />} title={t.career.detailsModal.responsibilities}>
                            <ul className="space-y-2 list-disc list-inside text-sm text-gray-300">
                                {details.dayToDayResponsibilities.map((item, i) => <li key={i}>{item}</li>)}
                            </ul>
                        </DetailSection>

                        <DetailSection icon={<CheckCircleIcon className="w-6 h-6" />} title={t.career.detailsModal.skills}>
                            <div className="flex flex-wrap gap-2">
                                {details.requiredSkills.map((skill, i) => (
                                    <span key={i} className="bg-cyan-900/50 text-cyan-300 text-xs font-semibold px-3 py-1 rounded-full">
                                        {skill}
                                    </span>
                                ))}
                            </div>
                        </DetailSection>

                        <DetailSection icon={<TrendingUpIcon className="w-6 h-6" />} title={t.career.detailsModal.progression}>
                           <p className="text-sm text-gray-300 whitespace-pre-wrap">{details.careerProgression}</p>
                        </DetailSection>
                    </div>
                )}
            </div>
        </Modal>
    );
};