import React, { useState, useEffect, useCallback } from 'react';
import { Modal } from './Modal';
import { useAuth } from '../hooks/useAuth';
import { getAnalyses } from '../services/firestoreService';
import type { AnalysisRecord } from '../types';
import { useI18n } from '../hooks/useI18n';
import { useError } from '../hooks/useError';

interface HistoryModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSelectAnalysis: (record: AnalysisRecord) => void;
}

const Loader: React.FC = () => (
    <div className="flex justify-center items-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-cyan-500"></div>
    </div>
);

export const HistoryModal: React.FC<HistoryModalProps> = ({ isOpen, onClose, onSelectAnalysis }) => {
    const { user } = useAuth();
    const { t } = useI18n();
    const { setError } = useError();
    const [history, setHistory] = useState<AnalysisRecord[]>([]);
    const [isLoading, setIsLoading] = useState(false);

    const fetchHistory = useCallback(async () => {
        if (!user) return;
        setIsLoading(true);
        setHistory([]);
        try {
            const records = await getAnalyses(user.uid);
            setHistory(records);
        } catch (err) {
            setError(t.error.auth.historyError, fetchHistory);
            onClose(); // Close modal on error to show the toast
        } finally {
            setIsLoading(false);
        }
    }, [user, setError, t.error.auth.historyError, onClose]);

    useEffect(() => {
        if (isOpen) {
            fetchHistory();
        }
    }, [isOpen, fetchHistory]);
    
    return (
        <Modal isOpen={isOpen} onClose={onClose} title={t.history.title}>
            <div className="p-1 min-h-[200px]">
                {isLoading && <Loader />}
                {!isLoading && history.length === 0 && (
                    <p className="text-gray-400 text-center p-4">{t.history.empty}</p>
                )}
                {!isLoading && history.length > 0 && (
                    <ul className="space-y-2">
                        {history.map(record => (
                            <li key={record.id}>
                                <button 
                                    onClick={() => onSelectAnalysis(record)}
                                    className="w-full text-left p-3 bg-slate-700/50 hover:bg-slate-600/50 rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-sky-500"
                                >
                                    <p className="font-semibold text-sky-400 truncate">{record.fileName}</p>
                                    <p className="text-xs text-gray-400">
                                        {new Date(record.timestamp).toLocaleString(undefined, { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                                    </p>
                                </button>
                            </li>
                        ))}
                    </ul>
                )}
            </div>
        </Modal>
    );
};