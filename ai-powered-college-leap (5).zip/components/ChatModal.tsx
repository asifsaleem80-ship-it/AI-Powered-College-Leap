import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GoogleGenAI, Chat, Modality, LiveServerMessage, Blob as GenAI_Blob } from '@google/genai';
import { Modal } from './Modal';
import { useI18n } from '../hooks/useI18n';
import type { StudentAnalysis, College, ChatMessage } from '../types';
import { SendIcon, MicrophoneIcon, StopIcon, SparklesIcon } from './icons';
import { locales } from '../i18n/locales';
import { decode, decodeAudioData, createBlob } from '../utils/audioUtils';

const API_KEY = process.env.API_KEY;

interface ChatModalProps {
    isOpen: boolean;
    onClose: () => void;
    analysis: StudentAnalysis;
    colleges: College[];
    locale: string;
}

const TypingIndicator = () => (
    <div className="flex items-center space-x-1 p-2">
        <div className="w-2 h-2 bg-fuchsia-400 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
        <div className="w-2 h-2 bg-fuchsia-400 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
        <div className="w-2 h-2 bg-fuchsia-400 rounded-full animate-bounce"></div>
    </div>
);

export const ChatModal: React.FC<ChatModalProps> = ({ isOpen, onClose, analysis, colleges, locale }) => {
    const { t } = useI18n();
    const [chat, setChat] = useState<Chat | null>(null);
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    // Voice Chat State
    const [isVoiceActive, setIsVoiceActive] = useState(false);
    const [voiceStatus, setVoiceStatus] = useState<'idle' | 'connecting' | 'listening'>('idle');
    const sessionPromiseRef = useRef<Promise<any> | null>(null);
    const inputAudioContextRef = useRef<AudioContext | null>(null);
    const outputAudioContextRef = useRef<AudioContext | null>(null);
    const mediaStreamRef = useRef<MediaStream | null>(null);
    const scriptProcessorRef = useRef<ScriptProcessorNode | null>(null);
    const nextStartTimeRef = useRef(0);
    const audioSourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

    // Refs for live transcription
    const currentInputTranscriptionRef = useRef('');
    const currentOutputTranscriptionRef = useRef('');

    const scrollToBottom = useCallback(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, []);

    useEffect(() => {
        scrollToBottom();
    }, [messages, isLoading, voiceStatus, scrollToBottom]);

    // Cleanup voice session on modal close or unmount
    useEffect(() => {
        return () => {
            if (sessionPromiseRef.current) {
                sessionPromiseRef.current.then((session: any) => session.close());
            }
            mediaStreamRef.current?.getTracks().forEach(track => track.stop());
            inputAudioContextRef.current?.close();
            outputAudioContextRef.current?.close();
        };
    }, []);

    const setupTextChat = useCallback(() => {
        if (!API_KEY) {
            console.error("API_KEY not found for chat");
            return;
        }
        const ai = new GoogleGenAI({ apiKey: API_KEY });
        const collegeList = colleges.map(c => `- ${c.name}: ${c.reason}`).join('\n');
        const pathwayList = analysis.pathways.map(p => `- ${p.name}: ${p.description}`).join('\n');
        const languageName = locales[locale]?.languageName || 'English';

        const systemInstruction = `You are a friendly and encouraging AI College Advisor. You are continuing a conversation with a student who has just received an analysis of their score report.

        This is the analysis you have already provided:
        - Summary of Strengths: ${analysis.summary}
        - Suggested Degree Pathways:
        ${pathwayList}
        - Recommended Colleges:
        ${collegeList}

        Your role is to answer the student's follow-up questions based on this context. Be supportive, provide detailed information when asked, and help them explore their options further. Do not repeat the initial analysis unless asked. Keep your answers concise and conversational.
        IMPORTANT: You MUST converse with the student in ${languageName}.`;

        const newChat = ai.chats.create({
            model: 'gemini-2.5-flash',
            config: { systemInstruction },
        });
        setChat(newChat);
        setMessages([{ role: 'model', message: t.chat.initialMessage }]);

    }, [analysis, colleges, locale, t.chat.initialMessage]);

    useEffect(() => {
        if (isOpen) {
            setupTextChat();
        } else {
            setChat(null);
            setMessages([]);
            setInput('');
            setIsLoading(false);
            if (isVoiceActive) {
                // Ensure voice chat is stopped and cleaned up when modal closes
                handleToggleVoiceChat();
            }
        }
    // handleToggleVoiceChat is a callback, adding it to dependencies would cause a loop
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [isOpen, setupTextChat]);


    const handleSendMessage = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!input.trim() || !chat || isLoading) return;

        const userMessage: ChatMessage = { role: 'user', message: input };
        setMessages(prev => [...prev, userMessage]);
        setInput('');
        setIsLoading(true);

        try {
            const response = await chat.sendMessage({ message: input });
            const modelMessage: ChatMessage = { role: 'model', message: response.text };
            setMessages(prev => [...prev, modelMessage]);
        } catch (error) {
            console.error("Error sending message:", error);
            const errorMessage: ChatMessage = { role: 'model', message: "Sorry, I encountered an error. Please try again." };
            setMessages(prev => [...prev, errorMessage]);
        } finally {
            setIsLoading(false);
        }
    };

    // --- VOICE CHAT LOGIC ---

    const stopVoiceChat = useCallback(() => {
        if (sessionPromiseRef.current) {
            sessionPromiseRef.current.then((session: any) => session.close());
            sessionPromiseRef.current = null;
        }
        mediaStreamRef.current?.getTracks().forEach(track => track.stop());
        mediaStreamRef.current = null;

        if (scriptProcessorRef.current) {
            scriptProcessorRef.current.disconnect();
            scriptProcessorRef.current = null;
        }

        inputAudioContextRef.current?.close().then(() => inputAudioContextRef.current = null);
        outputAudioContextRef.current?.close().then(() => outputAudioContextRef.current = null);
        
        audioSourcesRef.current.forEach(source => source.stop());
        audioSourcesRef.current.clear();
        nextStartTimeRef.current = 0;

        setIsVoiceActive(false);
        setVoiceStatus('idle');
    }, []);
    
    const handleToggleVoiceChat = useCallback(async () => {
        if (isVoiceActive) {
            stopVoiceChat();
            return;
        }

        if (!API_KEY) {
            console.error("API_KEY not found for voice chat");
            return;
        }
        
        setIsVoiceActive(true);
        setVoiceStatus('connecting');

        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            mediaStreamRef.current = stream;

            const ai = new GoogleGenAI({ apiKey: API_KEY });
            const collegeList = colleges.map(c => `- ${c.name}: ${c.reason}`).join('\n');
            const pathwayList = analysis.pathways.map(p => `- ${p.name}: ${p.description}`).join('\n');
            const languageName = locales[locale]?.languageName || 'English';

            inputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
            outputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
            
            sessionPromiseRef.current = ai.live.connect({
                model: 'gemini-2.5-flash-native-audio-preview-09-2025',
                config: {
                    responseModalities: [Modality.AUDIO],
                    inputAudioTranscription: {},
                    outputAudioTranscription: {},
                    systemInstruction: `You are a friendly and encouraging AI College Advisor, speaking to a student.
                        Context:
                        - Summary: ${analysis.summary}
                        - Pathways: ${pathwayList}
                        - Colleges: ${collegeList}
                        Keep your spoken answers concise and conversational. You MUST speak in ${languageName}.`,
                },
                callbacks: {
                    onopen: () => {
                        setVoiceStatus('listening');
                        const source = inputAudioContextRef.current!.createMediaStreamSource(stream);
                        const scriptProcessor = inputAudioContextRef.current!.createScriptProcessor(4096, 1, 1);
                        scriptProcessorRef.current = scriptProcessor;

                        scriptProcessor.onaudioprocess = (audioProcessingEvent) => {
                            const inputData = audioProcessingEvent.inputBuffer.getChannelData(0);
                            const pcmBlob = createBlob(inputData);
                            sessionPromiseRef.current?.then((session: any) => {
                                session.sendRealtimeInput({ media: pcmBlob });
                            });
                        };
                        source.connect(scriptProcessor);
                        scriptProcessor.connect(inputAudioContextRef.current!.destination);
                    },
                    onmessage: async (message: LiveServerMessage) => {
                        // Handle transcriptions
                        if (message.serverContent?.inputTranscription) {
                            currentInputTranscriptionRef.current += message.serverContent.inputTranscription.text;
                        }
                        if (message.serverContent?.outputTranscription) {
                            currentOutputTranscriptionRef.current += message.serverContent.outputTranscription.text;
                        }
                        if (message.serverContent?.turnComplete) {
                            const fullInput = currentInputTranscriptionRef.current.trim();
                            const fullOutput = currentOutputTranscriptionRef.current.trim();
                            
                            setMessages(prev => {
                                const newMessages = [...prev];
                                if (fullInput) newMessages.push({ role: 'user', message: fullInput });
                                if (fullOutput) newMessages.push({ role: 'model', message: fullOutput });
                                return newMessages;
                            });
                            
                            currentInputTranscriptionRef.current = '';
                            currentOutputTranscriptionRef.current = '';
                        }
                        
                        // Handle audio playback
                        const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
                        if (base64Audio && outputAudioContextRef.current) {
                            const outputCtx = outputAudioContextRef.current;
                            nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputCtx.currentTime);
                            const audioBuffer = await decodeAudioData(decode(base64Audio), outputCtx, 24000, 1);
                            
                            const source = outputCtx.createBufferSource();
                            source.buffer = audioBuffer;
                            source.connect(outputCtx.destination);
                            
                            source.addEventListener('ended', () => {
                                audioSourcesRef.current.delete(source);
                            });
                            
                            source.start(nextStartTimeRef.current);
                            nextStartTimeRef.current += audioBuffer.duration;
                            audioSourcesRef.current.add(source);
                        }
                        
                        // Handle interruption
                        if (message.serverContent?.interrupted) {
                            audioSourcesRef.current.forEach(source => source.stop());
                            audioSourcesRef.current.clear();
                            nextStartTimeRef.current = 0;
                        }
                    },
                    onclose: () => {
                        stopVoiceChat();
                    },
                    onerror: (e: ErrorEvent) => {
                        console.error("Voice chat error:", e);
                        stopVoiceChat();
                    },
                }
            });

        } catch (err) {
            console.error("Failed to start voice chat:", err);
            stopVoiceChat();
        }
    }, [isVoiceActive, stopVoiceChat, colleges, analysis, locale]);

    return (
        <Modal isOpen={isOpen} onClose={onClose} title="">
            <div className="flex flex-col h-[75vh]">
                <div className="p-4 border-b border-white/10 flex items-center space-x-4 rtl:space-x-reverse sticky top-0 bg-slate-900/80 backdrop-blur-md z-10">
                    <div className="w-12 h-12 rounded-full border-2 border-fuchsia-500 bg-slate-800 flex items-center justify-center">
                        <SparklesIcon className="w-8 h-8 text-fuchsia-400" />
                    </div>
                    <div>
                        <h2 className="text-lg font-semibold text-fuchsia-400">{t.chat.title}</h2>
                        <p className="text-xs text-gray-400">Powered by Gemini 2.5 Flash</p>
                    </div>
                </div>
                
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                    {messages.map((msg, index) => (
                        <div key={index} className={`flex items-end gap-2 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                           {msg.role === 'model' && <div className="w-6 h-6 rounded-full self-start bg-slate-700 flex items-center justify-center flex-shrink-0"><SparklesIcon className="w-4 h-4 text-fuchsia-400" /></div>}
                            <div className={`max-w-xs md:max-w-md lg:max-w-lg px-4 py-2 rounded-2xl ${msg.role === 'user' ? 'bg-gradient-to-r from-fuchsia-600 to-purple-600 text-white rounded-br-none rtl:rounded-br-2xl rtl:rounded-bl-none' : 'bg-slate-700 text-gray-200 rounded-bl-none rtl:rounded-bl-2xl rtl:rounded-br-none'}`}>
                                <p className="text-sm whitespace-pre-wrap">{msg.message}</p>
                            </div>
                        </div>
                    ))}
                    {isLoading && (
                         <div className="flex items-end gap-2 justify-start">
                            <div className="w-6 h-6 rounded-full self-start bg-slate-700 flex items-center justify-center flex-shrink-0"><SparklesIcon className="w-4 h-4 text-fuchsia-400" /></div>
                            <div className="bg-slate-700 rounded-2xl rounded-bl-none rtl:rounded-bl-2xl rtl:rounded-br-none">
                               <TypingIndicator />
                            </div>
                        </div>
                    )}
                    <div ref={messagesEndRef} />
                </div>

                <div className="p-4 border-t border-white/10">
                    <form onSubmit={handleSendMessage} className="flex items-center space-x-2 rtl:space-x-reverse">
                        <input
                            type="text"
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                            placeholder={isVoiceActive ? t.chat[voiceStatus] : t.chat.placeholder}
                            className="flex-1 bg-white/5 border border-white/10 rounded-full px-4 py-2 text-white focus:ring-fuchsia-500 focus:border-fuchsia-500"
                            disabled={isLoading || isVoiceActive}
                        />
                        <button
                            type="submit"
                            disabled={isLoading || !input.trim() || isVoiceActive}
                            className="bg-purple-600 hover:bg-purple-500 disabled:bg-gray-600 disabled:cursor-not-allowed text-white rounded-full p-3 transition-colors"
                            aria-label="Send message"
                        >
                            <SendIcon className="w-5 h-5" />
                        </button>
                        <button
                            type="button"
                            onClick={handleToggleVoiceChat}
                            className={`p-3 rounded-full transition-colors ${
                                isVoiceActive
                                ? 'bg-red-600 hover:bg-red-500 text-white animate-pulse'
                                : 'bg-gray-600 hover:bg-gray-500 text-white'
                            }`}
                            aria-label={isVoiceActive ? t.chat.stopVoice : t.chat.startVoice}
                            title={isVoiceActive ? t.chat.stopVoice : t.chat.startVoice}
                        >
                            {isVoiceActive ? <StopIcon className="w-6 h-6" /> : <MicrophoneIcon className="w-6 h-6" />}
                        </button>
                    </form>
                </div>
            </div>
        </Modal>
    );
};