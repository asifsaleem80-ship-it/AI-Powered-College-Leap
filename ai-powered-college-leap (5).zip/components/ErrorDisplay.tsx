import React, { useEffect } from 'react';
import { useError } from '../hooks/useError';
import { useI18n } from '../hooks/useI18n';
import { InformationCircleIcon, XIcon } from './icons';

export const ErrorDisplay: React.FC = () => {
    const { error, clearError } = useError();
    const { t } = useI18n();

    useEffect(() => {
        if (error && !error.onRetry) {
            const timer = setTimeout(() => {
                clearError();
            }, 8000);
            return () => clearTimeout(timer);
        }
    }, [error, clearError]);

    if (!error) {
        return null;
    }

    const handleRetry = () => {
        // Clear error first to hide the toast, then retry
        clearError();
        // A small delay can prevent race conditions with the new loading state
        setTimeout(() => {
            error.onRetry?.();
        }, 50);
    };

    return (
        <div
            role="alert"
            className="fixed bottom-4 inset-x-4 sm:bottom-6 sm:left-1/2 sm:-translate-x-1/2 max-w-lg z-[100] transition-all duration-300 animate-slide-up-fade"
        >
            <div className="bg-red-900/50 backdrop-blur-lg border border-red-500/50 rounded-lg p-4 shadow-2xl shadow-red-500/20 flex items-start gap-4">
                <div className="flex-shrink-0 pt-0.5">
                    <InformationCircleIcon className="w-6 h-6 text-red-300" />
                </div>
                <div className="flex-1">
                    <p className="text-red-200 text-sm font-medium">{error.message}</p>
                    {error.onRetry && (
                        <button
                            onClick={handleRetry}
                            className="mt-2 px-3 py-1 text-sm font-semibold bg-red-300 text-red-900 rounded-md hover:bg-red-200 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-red-900/50 focus:ring-red-300"
                        >
                            {t.error.tryAgain}
                        </button>
                    )}
                </div>
                <div className="flex-shrink-0">
                    <button
                        onClick={clearError}
                        className="p-1 rounded-full text-red-300 hover:bg-white/10 transition-colors"
                        aria-label={t.error.dismiss}
                    >
                        <XIcon className="w-5 h-5" />
                    </button>
                </div>
            </div>
            <style>{`
                @keyframes slide-up-fade {
                    0% {
                        opacity: 0;
                        transform: translateY(20px) translateX(-50%);
                    }
                    100% {
                        opacity: 1;
                        transform: translateY(0) translateX(-50%);
                    }
                }
                .animate-slide-up-fade {
                    animation: slide-up-fade 0.3s ease-out forwards;
                }
                @media (max-width: 639px) {
                    @keyframes slide-up-fade {
                        0% {
                            opacity: 0;
                            transform: translateY(20px);
                        }
                        100% {
                            opacity: 1;
                            transform: translateY(0);
                        }
                    }
                }
            `}</style>
        </div>
    );
};