import React, { useState, useCallback, memo } from 'react';
import type { College, CollegeDetails } from '../types';
import { useI18n } from '../hooks/useI18n';
import { SparklesIcon } from './icons';
import { getCollegeDetails } from '../services/geminiService';
import { CollegeDetailsDisplay } from './CollegeDetailsDisplay';
import { ShareDropdown } from './ShareDropdown';


interface CollegeCardProps {
  college: College;
  studentSummary: string;
  languageName: string;
}

export const CollegeCard: React.FC<CollegeCardProps> = memo(({ college, studentSummary, languageName }) => {
  const { t } = useI18n();

  const [isOpen, setIsOpen] = useState(false);
  const [details, setDetails] = useState<CollegeDetails | null>(null);
  const [isLoadingDetails, setIsLoadingDetails] = useState(false);
  const [detailsError, setDetailsError] = useState<string | null>(null);

  const fetchDetails = useCallback(async () => {
    setIsLoadingDetails(true);
    setDetailsError(null);
    try {
      const fetchedDetails = await getCollegeDetails(college.name, studentSummary, languageName);
      setDetails(fetchedDetails);
    } catch (err) {
      console.error("Failed to fetch college details:", err);
      setDetailsError(t.collegeCard.error.details);
    } finally {
      setIsLoadingDetails(false);
    }
  }, [college.name, studentSummary, languageName, t.collegeCard.error.details]);

  const handleToggle = useCallback(async () => {
    const opening = !isOpen;
    setIsOpen(opening);

    if (opening && !details && !detailsError) {
      fetchDetails();
    }
  }, [isOpen, details, detailsError, fetchDetails]);
  
  const handleRetry = fetchDetails;

  const shareText = `${t.share.collegePrefix.replace('{collegeName}', college.name)}\n\n"${college.reason}"\n\n${t.share.checkOut}`;

  return (
    <article className="bg-black/20 backdrop-blur-lg border border-white/10 rounded-2xl p-6 shadow-lg hover:border-fuchsia-500/50 hover:shadow-2xl hover:shadow-fuchsia-500/10 transition-all duration-300 transform hover:-translate-y-1">
      <div className="flex justify-between items-start gap-4">
          <div className="flex-1">
              <h3 className="text-xl font-bold text-fuchsia-400 mb-2">{college.name}</h3>
              <p className="text-gray-300 mb-4 text-sm">{college.reason}</p>
              <div className="text-gray-400 text-sm mb-4 space-y-1">
                <div>
                  <span className="font-semibold">{t.collegeCard.tuitionLocal}:</span> {college.estimatedTuitionLocal}
                </div>
                <div>
                  <span className="font-semibold">{t.collegeCard.tuitionInternational}:</span> {college.estimatedTuitionInternational}
                </div>
              </div>
              <a
                href={college.website}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block text-fuchsia-400 hover:text-fuchsia-300 font-semibold transition-colors duration-300 text-sm"
              >
                Visit Website &rarr;
                <span className="sr-only">(opens in a new tab)</span>
              </a>
          </div>
          <div className="flex flex-col items-center gap-2">
            <button
              onClick={handleToggle}
              className="text-sm font-semibold text-fuchsia-400 hover:bg-white/10 border border-fuchsia-500/50 rounded-md px-3 py-1 transition-colors whitespace-nowrap"
              aria-expanded={isOpen}
            >
              {isOpen ? t.collegeCard.showLess : t.collegeCard.showMore}
            </button>
            <ShareDropdown
                shareText={shareText}
                shareTitle={t.share.collegeTitle.replace('{collegeName}', college.name)}
                isSmall={true}
            />
          </div>
      </div>

      {college.scholarships && college.scholarships.length > 0 && (
         <div className="mt-4 pt-4 border-t border-white/10">
            <h4 className="flex items-center text-sm font-semibold text-fuchsia-400 mb-3">
                <SparklesIcon className="w-4 h-4 mr-2 rtl:ml-2 rtl:mr-0" />
                {t.collegeCard.scholarshipTitle}
            </h4>
            <div className="space-y-3">
                {college.scholarships.map((scholarship, index) => (
                    <div key={index} className="text-sm bg-slate-800/40 p-4 rounded-xl border border-fuchsia-500/10 hover:border-fuchsia-500/30 hover:bg-slate-800/60 transition-all duration-300 shadow-inner shadow-black/20">
                        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start gap-2 sm:gap-4">
                            {scholarship.website ? (
                                <a 
                                    href={scholarship.website} 
                                    target="_blank" 
                                    rel="noopener noreferrer" 
                                    className="font-semibold text-gray-200 hover:text-fuchsia-300 transition-colors group"
                                >
                                    {scholarship.name}
                                    <span className="inline-block transition-transform group-hover:translate-x-1 rtl:group-hover:-translate-x-1 motion-reduce:transform-none ml-1 rtl:mr-1 rtl:ml-0">&rarr;</span>
                                    <span className="sr-only">(opens in a new tab)</span>
                                </a>
                            ) : (
                                <h5 className="font-semibold text-gray-200">{scholarship.name}</h5>
                            )}
                            <p className="text-fuchsia-300 font-bold text-xs bg-fuchsia-900/50 px-2 py-1 rounded-full self-start sm:self-center">{scholarship.estimatedAmount}</p>
                        </div>
                        <p className="text-gray-400 mt-1 text-xs italic">{scholarship.description}</p>
                        <p className="text-gray-400 mt-2 text-xs"><span className="font-semibold text-gray-300">{t.collegeCard.eligibility}:</span> {scholarship.eligibility}</p>
                    </div>
                ))}
            </div>
        </div>
      )}

      <div
        className={`
          transition-all duration-500 ease-in-out overflow-hidden
          ${isOpen 
              ? 'max-h-[3000px] opacity-100 mt-6 pt-6 border-t border-fuchsia-500/20' 
              : 'max-h-0 opacity-0 mt-0 pt-0 border-t border-transparent'
          }
        `}
      >
          {detailsError && !isLoadingDetails ? (
            <div className="text-center p-4 bg-red-900/20 border border-red-500/30 rounded-lg flex flex-col items-center">
              <p className="text-red-300 mb-3">{detailsError}</p>
              <button
                onClick={handleRetry}
                className="px-4 py-2 text-sm font-semibold bg-red-600 text-white rounded-md hover:bg-red-500 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-red-500"
              >
                {t.error.tryAgain}
              </button>
            </div>
          ) : (
            <CollegeDetailsDisplay 
                collegeName={college.name}
                studentSummary={studentSummary}
                languageName={languageName}
                isLoadingDetails={isLoadingDetails}
                details={details}
            />
          )}
      </div>
    </article>
  );
});