import React, { useState, useCallback } from 'react';
import type { CareerData, CareerPath, CareerPathDetails } from '../types';
import { useI18n } from '../hooks/useI18n';
import { getCareerPathDetails } from '../services/geminiService';
import { locales } from '../i18n/locales';
import { CareerPathDetailModal } from './CareerPathDetailModal';
import { 
    ChartBarIcon, 
    TrendingUpIcon, 
    UsersGroupIcon,
    BriefcaseIcon,
    BuildingOfficeIcon,
    CurrencyDollarIcon,
    BookmarkIcon
} from './icons';

interface CareerOpportunitiesProps {
  careerData: CareerData;
  degreeName: string;
  locale: string;
}

const InfoCard: React.FC<{ icon: React.ReactNode, title: string, value: string | number }> = ({ icon, title, value }) => {
    const valueStr = String(value);
    // Reduce font size for long strings like salary ranges to prevent overflow
    const fontSizeClass = valueStr.length > 15 ? 'text-xl' : 'text-2xl';

    return (
        <div className="bg-slate-800/40 p-4 rounded-xl shadow-inner border border-white/10 text-center">
            <div className="w-10 h-10 mx-auto mb-2 flex items-center justify-center text-cyan-400">
                {icon}
            </div>
            <p className={`${fontSizeClass} font-bold text-white break-words`}>{value}</p>
            <p className="text-sm font-semibold text-gray-300">{title}</p>
        </div>
    );
};

export const CareerOpportunities: React.FC<CareerOpportunitiesProps> = ({ careerData, degreeName, locale }) => {
  const { t } = useI18n();
  const { jobMarketOverview, careerPathCount, industryCount, averageSalaryRange, topCareerPaths } = careerData;

  const [selectedPath, setSelectedPath] = useState<CareerPath | null>(null);
  const [details, setDetails] = useState<CareerPathDetails | null>(null);
  const [isLoadingDetails, setIsLoadingDetails] = useState(false);
  const [detailError, setDetailError] = useState<string | null>(null);

  const handleViewDetails = useCallback(async (path: CareerPath) => {
    setSelectedPath(path);
    setIsLoadingDetails(true);
    setDetails(null);
    setDetailError(null);

    try {
        const languageName = locales[locale]?.languageName || 'English';
        const fetchedDetails = await getCareerPathDetails(path.title, degreeName, languageName);
        setDetails(fetchedDetails);
    } catch (err) {
        console.error("Failed to fetch career path details:", err);
        setDetailError(t.career.detailsModal.error);
    } finally {
        setIsLoadingDetails(false);
    }
  }, [locale, degreeName, t.career.detailsModal.error]);

  const handleCloseModal = () => {
    setSelectedPath(null);
    setDetails(null);
    setDetailError(null);
  };
  
  const handleRetry = () => {
      if (selectedPath) {
          handleViewDetails(selectedPath);
      }
  }

  return (
    <>
        <div className="bg-black/20 backdrop-blur-lg text-white p-6 rounded-2xl border border-white/10 shadow-lg">
          <h2 className="text-2xl font-bold text-center text-cyan-400 mb-2">
            {t.career.title.replace('{degreeName}', degreeName)}
          </h2>
          <div className="w-20 h-1 bg-cyan-400 mx-auto mb-8 rounded-full"></div>

          <div className="bg-slate-800/40 p-6 rounded-xl shadow-inner border border-cyan-500/10 mb-8">
            <h3 className="text-xl font-bold text-cyan-400 mb-4">{t.career.jobMarket}</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="flex items-start gap-4">
                <ChartBarIcon className="w-8 h-8 text-cyan-400 flex-shrink-0 mt-1" />
                <div>
                  <h4 className="font-bold text-gray-200">{t.career.outlook}</h4>
                  <p className="text-sm text-gray-300">{jobMarketOverview.overallOutlook}</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <TrendingUpIcon className="w-8 h-8 text-cyan-400 flex-shrink-0 mt-1" />
                <div>
                  <h4 className="font-bold text-gray-200">{t.career.growth}</h4>
                  <p className="text-sm text-gray-300">{jobMarketOverview.growthRate}</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <UsersGroupIcon className="w-8 h-8 text-cyan-400 flex-shrink-0 mt-1" />
                <div>
                  <h4 className="font-bold text-gray-200">{t.career.competition}</h4>
                  <p className="text-sm text-gray-300">{jobMarketOverview.competitionLevel}</p>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
              <InfoCard icon={<BriefcaseIcon />} title={t.career.paths} value={careerPathCount} />
              <InfoCard icon={<BuildingOfficeIcon />} title={t.career.industries} value={industryCount} />
              <InfoCard icon={<CurrencyDollarIcon />} title={t.career.salary} value={averageSalaryRange} />
          </div>

          <div>
            <h3 className="text-xl font-bold text-cyan-400 mb-4">{t.career.topPaths}</h3>
            <div className="space-y-4">
              {topCareerPaths.map((path, index) => (
                 <button 
                    key={index} 
                    onClick={() => handleViewDetails(path)}
                    className="w-full text-left bg-slate-800/40 p-5 rounded-xl shadow-md border border-white/10 relative hover:bg-slate-700/60 hover:border-cyan-500/30 transition-all transform hover:scale-[1.02] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-cyan-500"
                >
                    <BookmarkIcon className="absolute top-4 right-4 rtl:right-auto rtl:left-4 w-8 h-8 text-cyan-500/50" />
                    <h4 className="font-bold text-lg text-white mb-1">{path.title}</h4>
                    <p className="text-sm text-gray-300">{path.description}</p>
                </button>
              ))}
            </div>
          </div>
        </div>
        
        {selectedPath && (
            <CareerPathDetailModal 
                isOpen={!!selectedPath}
                onClose={handleCloseModal}
                careerTitle={selectedPath.title}
                details={details}
                isLoading={isLoadingDetails}
                error={detailError}
                onRetry={handleRetry}
            />
        )}
    </>
  );
};