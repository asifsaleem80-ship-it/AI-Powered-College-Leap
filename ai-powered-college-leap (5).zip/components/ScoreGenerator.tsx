import React, { useState, useCallback, useRef } from 'react';
import { GRADES } from '../constants';
import { GenerateIcon, DownloadIcon, TrashIcon, ChevronDownIcon } from './icons';
import { useI18n } from '../hooks/useI18n';

interface Subject {
  id: number;
  name: string;
  minScore: number;
  maxScore: number;
}

const initialSubjects: Subject[] = [
  { id: 1, name: 'Mathematics', minScore: 85, maxScore: 95 },
  { id: 2, name: 'Physics', minScore: 90, maxScore: 100 },
  { id: 3, name: 'Chemistry', minScore: 80, maxScore: 92 },
  { id: 4, name: 'English Literature', minScore: 75, maxScore: 88 },
  { id: 5, name: 'History', minScore: 82, maxScore: 94 },
];

export const ScoreGenerator: React.FC = () => {
    const { t, dir } = useI18n();
    const [studentName, setStudentName] = useState<string>('Alex Doe');
    const [grade, setGrade] = useState<string>(GRADES[0]);
    const [subjects, setSubjects] = useState<Subject[]>(initialSubjects);
    const [generatedImage, setGeneratedImage] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);

    const handleAddSubject = () => {
        setSubjects([...subjects, { id: Date.now(), name: '', minScore: 70, maxScore: 100 }]);
    };

    const handleRemoveSubject = (id: number) => {
        setSubjects(subjects.filter(s => s.id !== id));
    };

    const handleSubjectChange = (id: number, field: keyof Omit<Subject, 'id'>, value: string | number) => {
        setSubjects(subjects.map(s => s.id === id ? { ...s, [field]: value } : s));
    };

    const handleGenerateReport = useCallback(() => {
        setError(null);
        for (const subject of subjects) {
            if (subject.minScore > subject.maxScore) {
                setError(t.scoreGenerator.error.minMax);
                return;
            }
        }

        const canvas = canvasRef.current;
        if (!canvas) return;

        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        const isRTL = dir === 'rtl';
        const width = 800;
        const height = 1100;
        canvas.width = width;
        canvas.height = height;
        ctx.direction = isRTL ? 'rtl' : 'ltr';

        // Background
        ctx.fillStyle = '#111827'; // gray-900
        ctx.fillRect(0, 0, width, height);
        
        // Border
        ctx.strokeStyle = '#a855f7'; // purple-500
        ctx.lineWidth = 10;
        ctx.strokeRect(0, 0, width, height);

        // Header
        ctx.fillStyle = '#f0abfc'; // fuchsia-300
        ctx.font = 'bold 48px Inter, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(t.scoreGenerator.canvas.title, width / 2, 100);

        // Student Info
        const infoX = isRTL ? width - 50 : 50;
        ctx.textAlign = isRTL ? 'right' : 'left';
        ctx.fillStyle = '#e5e7eb'; // gray-200
        ctx.font = '24px Inter, sans-serif';
        ctx.fillText(`${t.scoreGenerator.canvas.student}: ${studentName}`, infoX, 180);
        ctx.fillText(`${t.scoreGenerator.canvas.grade}: ${grade}`, infoX, 220);

        // Table Header
        const subjectX = isRTL ? width - 150 : 150;
        const scoreX = isRTL ? width - 550 : 550;
        ctx.font = 'bold 28px Inter, sans-serif';
        ctx.fillText(t.scoreGenerator.canvas.subject, subjectX, 300);
        ctx.fillText(t.scoreGenerator.canvas.score, scoreX, 300);
        
        // Divider line
        ctx.strokeStyle = '#4b5563'; // gray-600
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(50, 320);
        ctx.lineTo(width - 50, 320);
        ctx.stroke();

        // Table Rows
        ctx.font = '24px Inter, sans-serif';
        let yPos = 360;
        subjects.forEach(subject => {
            if (subject.name) {
                const score = Math.floor(Math.random() * (subject.maxScore - subject.minScore + 1)) + subject.minScore;
                ctx.fillText(subject.name, subjectX, yPos);
                ctx.fillText(String(score), scoreX, yPos);
                yPos += 50;
            }
        });

        // Footer
        ctx.fillStyle = '#9ca3af'; // gray-400
        ctx.font = 'italic 18px Inter, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(t.scoreGenerator.canvas.issuedBy, width / 2, height - 50);

        setGeneratedImage(canvas.toDataURL('image/png'));
    }, [studentName, grade, subjects, t, dir]);

    const handleDownloadImage = () => {
        if (!generatedImage) return;
        const link = document.createElement('a');
        link.href = generatedImage;
        link.download = 'score-report.png';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    return (
        <div className="bg-gray-900/30 backdrop-blur-xl border border-white/10 rounded-2xl p-6 sm:p-8 h-full">
            <h2 className="text-2xl font-bold text-fuchsia-400 mb-1">{t.scoreGenerator.title}</h2>
            <p className="text-gray-400 mb-6 text-sm">{t.scoreGenerator.subtitle}</p>
            
            <div className="space-y-4">
                <div>
                    <label htmlFor="student-name" className="block text-sm font-medium text-gray-300 mb-1 text-left rtl:text-right">{t.scoreGenerator.studentName}</label>
                    <input 
                        type="text" 
                        id="student-name"
                        value={studentName}
                        onChange={(e) => setStudentName(e.target.value)}
                        className="w-full bg-white/5 border border-white/10 rounded-md px-3 py-2 text-white focus:ring-fuchsia-500 focus:border-fuchsia-500"
                    />
                </div>
                <div>
                    <label htmlFor="grade" className="block text-sm font-medium text-gray-300 mb-1 text-left rtl:text-right">{t.scoreGenerator.grade}</label>
                    <div className="relative">
                        <select
                            id="grade"
                            value={grade}
                            onChange={(e) => setGrade(e.target.value)}
                            className="w-full bg-white/5 border border-white/10 rounded-md pl-3 pr-8 py-2 text-white focus:ring-fuchsia-500 focus:border-fuchsia-500 appearance-none"
                        >
                            {GRADES.map(g => <option key={g} value={g} className="bg-slate-800 text-white">{g}</option>)}
                        </select>
                        <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-400">
                            <ChevronDownIcon className="w-4 h-4" />
                        </div>
                    </div>
                </div>
            </div>

            <div className="mt-6">
                <h3 className="text-sm font-medium text-gray-300 mb-2 text-left rtl:text-right">{t.scoreGenerator.subjectsTitle}</h3>
                <div className="space-y-3 max-h-48 overflow-y-auto pr-2 rtl:pr-0 rtl:pl-2">
                    {subjects.map((subject, index) => (
                        <div key={subject.id} className="grid grid-cols-1 sm:grid-cols-[1fr,auto,auto,auto] gap-2 items-center">
                            <input 
                                type="text"
                                placeholder={`Subject ${index + 1}`}
                                value={subject.name}
                                onChange={(e) => handleSubjectChange(subject.id, 'name', e.target.value)}
                                className="bg-white/5 border border-white/10 rounded-md px-3 py-1.5 text-white text-sm"
                            />
                            <input 
                                type="number"
                                placeholder="Min"
                                value={subject.minScore}
                                onChange={(e) => handleSubjectChange(subject.id, 'minScore', parseInt(e.target.value, 10) || 0)}
                                className="bg-white/5 border border-white/10 rounded-md px-2 py-1.5 text-white w-20 text-sm"
                            />
                            <input 
                                type="number"
                                placeholder="Max"
                                value={subject.maxScore}
                                onChange={(e) => handleSubjectChange(subject.id, 'maxScore', parseInt(e.target.value, 10) || 0)}
                                className="bg-white/5 border border-white/10 rounded-md px-2 py-1.5 text-white w-20 text-sm"
                            />
                            <button onClick={() => handleRemoveSubject(subject.id)} className="text-gray-400 hover:text-red-400 p-3 rounded-full">
                                <TrashIcon className="w-4 h-4" />
                            </button>
                        </div>
                    ))}
                </div>
                 <button onClick={handleAddSubject} className="mt-2 text-sm text-fuchsia-400 hover:text-fuchsia-300">
                    {t.scoreGenerator.addSubject}
                </button>
            </div>

            {error && <p className="text-red-400 text-sm text-center mt-4">{error}</p>}
            
            <button
                onClick={handleGenerateReport}
                className="w-full mt-6 flex items-center justify-center bg-fuchsia-600 hover:bg-fuchsia-500 text-white font-bold py-2 px-4 rounded-lg transition-colors"
            >
                <GenerateIcon className="w-5 h-5 mr-2 rtl:ml-2 rtl:mr-0" />
                {t.scoreGenerator.generateButton}
            </button>

            <div className="mt-6">
                <canvas ref={canvasRef} className="hidden"></canvas>
                {generatedImage ? (
                    <div className="space-y-4">
                        <img src={generatedImage} alt="Generated score report" className="w-full rounded-md border-2 border-white/10" />
                        <button 
                            onClick={handleDownloadImage} 
                            className="w-full flex items-center justify-center bg-gray-600 hover:bg-gray-500 text-white font-bold py-2 px-4 rounded-lg transition-colors">
                            <DownloadIcon className="w-5 h-5 mr-2 rtl:ml-2 rtl:mr-0" />
                            {t.scoreGenerator.downloadButton}
                        </button>
                    </div>
                ) : (
                    <div className="w-full h-48 bg-white/5 rounded-md flex items-center justify-center border-2 border-dashed border-white/10">
                        <p className="text-gray-500">{t.scoreGenerator.imagePlaceholder}</p>
                    </div>
                )}
            </div>

        </div>
    );
};