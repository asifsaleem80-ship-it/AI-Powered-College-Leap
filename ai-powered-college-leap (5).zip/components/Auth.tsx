import React, { useEffect, useRef, useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import { useI18n } from '../hooks/useI18n';
import { isFirebaseConfigured } from '../services/firebase';
import { UserCircleIcon } from './icons';

const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID;

interface AuthProps {
    onShowHistory: () => void;
    onShowFavorites: () => void;
    onSignIn: () => void;
}

export const Auth: React.FC<AuthProps> = ({ onShowHistory, onShowFavorites, onSignIn }) => {
    const { user, logout } = useAuth();
    const { t } = useI18n();
    const [isDropdownOpen, setIsDropdownOpen] = useState(false);
    const dropdownRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        function handleClickOutside(event: MouseEvent) {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
                setIsDropdownOpen(false);
            }
        }
        document.addEventListener("mousedown", handleClickOutside);
        return () => {
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, [dropdownRef]);

    if (!isFirebaseConfigured || !GOOGLE_CLIENT_ID) {
        return null; // Gracefully hide auth features if not configured
    }

    if (!user) {
        return (
            <button
                onClick={onSignIn}
                className="flex items-center gap-2 bg-gray-700/50 border border-gray-600 rounded-md px-3 py-2 text-white hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-sky-500 transition-colors text-sm"
            >
                <UserCircleIcon className="w-5 h-5" />
                <span>{t.auth.signIn}</span>
            </button>
        );
    }

    return (
        <div className="relative" ref={dropdownRef}>
            <button 
                onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                className="flex items-center space-x-2 p-1 rounded-full bg-gray-700/50 hover:bg-gray-600/50 transition-colors"
                aria-haspopup="true"
                aria-expanded={isDropdownOpen}
            >
                <img src={user.picture} alt="User avatar" className="w-8 h-8 rounded-full" />
                <span className="text-white font-medium pr-2 text-sm hidden sm:inline">{user.name}</span>
            </button>
            {isDropdownOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-slate-800 border border-gray-700 rounded-md shadow-lg z-20">
                    <div className="py-1" role="menu" aria-orientation="vertical">
                        {isFirebaseConfigured && (
                            <>
                                <button
                                    onClick={() => {
                                        onShowFavorites();
                                        setIsDropdownOpen(false);
                                    }}
                                    className="block w-full text-left px-4 py-2 text-sm text-gray-300 hover:bg-slate-700"
                                    role="menuitem"
                                >
                                    {t.auth.myFavorites}
                                </button>
                                <button
                                    onClick={() => {
                                        onShowHistory();
                                        setIsDropdownOpen(false);
                                    }}
                                    className="block w-full text-left px-4 py-2 text-sm text-gray-300 hover:bg-slate-700"
                                    role="menuitem"
                                >
                                    {t.auth.myHistory}
                                </button>
                            </>
                        )}
                        <button
                            onClick={() => {
                                logout();
                                setIsDropdownOpen(false);
                            }}
                            className="block w-full text-left px-4 py-2 text-sm text-gray-300 hover:bg-slate-700"
                            role="menuitem"
                        >
                            {t.auth.logout}
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
};