import React, { useEffect, useRef } from 'react';
import { Modal } from './Modal';
import { useAuth } from '../hooks/useAuth';
import { useI18n } from '../hooks/useI18n';
import { UserCircleIcon } from './icons';

interface SignInModalProps {
    isOpen: boolean;
    onClose: () => void;
}

export const SignInModal: React.FC<SignInModalProps> = ({ isOpen, onClose }) => {
    const { user, isGsiReady } = useAuth();
    const { t, locale } = useI18n();
    const googleButtonRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        // If user logs in while modal is open, close it
        if (user && isOpen) {
            onClose();
        }
    }, [user, isOpen, onClose]);

    useEffect(() => {
        if (isOpen && !user && isGsiReady && window.google?.accounts?.id && googleButtonRef.current) {
            googleButtonRef.current.innerHTML = ''; // Clear previous button
            window.google.accounts.id.renderButton(
                googleButtonRef.current,
                { 
                    theme: 'filled_blue', // Change theme to be more prominent
                    size: 'large', 
                    type: 'standard', 
                    text: 'signin_with', 
                    shape: 'pill',
                    width: '280', // Set a fixed width for consistency
                    locale: locale 
                }
            );
        }
    }, [isOpen, user, locale, isGsiReady]);

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={t.signInModal.title}>
            <div className="flex flex-col items-center p-6 sm:p-8 text-center space-y-6">
                 <div className="p-3 bg-slate-700 rounded-full">
                    <UserCircleIcon className="w-12 h-12 text-sky-400" />
                </div>
                <p className="text-lg text-gray-300 max-w-sm">{t.signInModal.subtitle}</p>
                <div ref={googleButtonRef} className="h-[50px] flex justify-center items-center">
                    {!isGsiReady && <div className="text-sm text-gray-400">Loading sign-in options...</div>}
                </div>
            </div>
        </Modal>
    );
};