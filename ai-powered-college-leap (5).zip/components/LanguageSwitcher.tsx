import React, { useState, useRef, useEffect, memo } from 'react';
import { useI18n } from '../hooks/useI18n';
import { locales } from '../i18n/locales';
import { LanguageIcon } from './icons';

export const LanguageSwitcher: React.FC = memo(() => {
  const { locale, setLocale } = useI18n();
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const handleLanguageChange = (langCode: string) => {
    setLocale(langCode);
    setIsOpen(false);
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const currentLanguageName = locales[locale]?.languageLabel || 'Language';

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 bg-black/20 backdrop-blur-lg border border-white/10 rounded-md px-3 py-2 text-white hover:bg-white/10 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-fuchsia-500 transition-colors text-sm"
        aria-haspopup="true"
        aria-expanded={isOpen}
      >
        <LanguageIcon className="w-5 h-5 text-gray-400" />
        <span>{currentLanguageName}</span>
        <span className={`inline-block text-gray-400 transition-transform ${isOpen ? 'rotate-180' : ''}`} aria-hidden="true">
         ▾
        </span>
      </button>

      {isOpen && (
        <div className="absolute right-0 rtl:right-auto rtl:left-0 mt-2 w-40 bg-slate-900/80 backdrop-blur-lg border border-white/10 rounded-md shadow-lg z-20 py-1">
          {Object.keys(locales).map((key) => (
            <button
              key={key}
              onClick={() => handleLanguageChange(key)}
              className={`block w-full text-left rtl:text-right px-4 py-2 text-sm transition-colors ${
                locale === key ? 'bg-fuchsia-600 text-white' : 'text-gray-300 hover:bg-white/10'
              }`}
            >
              {locales[key].languageLabel}
            </button>
          ))}
        </div>
      )}
    </div>
  );
});