import React, { useState, useCallback, memo } from 'react';
import type { DegreePathway, CareerData } from '../types';
import { BookOpenIcon } from './icons';
import { useI18n } from '../hooks/useI18n';
import { useError } from '../hooks/useError';
import { getCareerOpportunities } from '../services/geminiService';
import { CareerOpportunities } from './CareerOpportunities';
import { locales } from '../i18n/locales';


interface DegreePathwayCardProps {
  pathway: DegreePathway;
  locale: string;
}

const DegreePathwayCard: React.FC<DegreePathwayCardProps> = memo(({ pathway, locale }) => {
    const { t } = useI18n();
    const { setError } = useError();
    const [isOpen, setIsOpen] = useState(false);
    const [careerData, setCareerData] = useState<CareerData | null>(null);
    const [isLoading, setIsLoading] = useState(false);

    const fetchCareerData = useCallback(async () => {
        setIsLoading(true);
        try {
            const languageName = locales[locale]?.languageName || 'English';
            const data = await getCareerOpportunities(pathway.name, languageName);
            setCareerData(data);
        } catch (err) {
            console.error(err);
            setError(t.career.error, fetchCareerData);
            setIsOpen(false); // Close on error
        } finally {
            setIsLoading(false);
        }
    }, [pathway.name, locale, setError, t.career.error]);

    const handleToggle = () => {
        const nextIsOpen = !isOpen;
        setIsOpen(nextIsOpen);
        if (nextIsOpen && !careerData) {
            fetchCareerData();
        }
    };

    return (
        <div className="border-l-4 rtl:border-l-0 rtl:border-r-4 border-fuchsia-500/50 pl-4 rtl:pl-0 rtl:pr-4">
            <h4 className="font-semibold text-lg text-white">{pathway.name}</h4>
            <p className="text-gray-300 text-sm mt-1 mb-3">{pathway.description}</p>
            <div className="flex flex-wrap gap-2 items-center">
                <span className="text-gray-400 text-xs font-semibold mr-2 rtl:ml-2 rtl:mr-0">{t.degreePathways.careerOptions}:</span>
                {pathway.careerOptions.map((career, i) => (
                    <span key={i} className="bg-fuchsia-900/50 text-fuchsia-300 text-xs font-medium px-2.5 py-1 rounded-full">
                        {career}
                    </span>
                ))}
            </div>
             <div className="mt-4">
                <button 
                    onClick={handleToggle}
                    className="text-sm font-semibold text-cyan-400 hover:text-cyan-300 transition-colors hover:underline"
                    aria-expanded={isOpen}
                >
                    {isOpen ? t.career.hideButton : t.career.viewButton}
                </button>
            </div>
            <div className={`transition-all duration-500 ease-in-out overflow-hidden ${isOpen ? 'max-h-[3000px] mt-4' : 'max-h-0'}`}>
                {isLoading && (
                    <div className="flex justify-center items-center py-8">
                        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-cyan-500"></div>
                    </div>
                )}
                {careerData && <CareerOpportunities careerData={careerData} degreeName={pathway.name} locale={locale} />}
            </div>
        </div>
    )
});


interface DegreePathwaysProps {
  pathways: DegreePathway[];
  locale: string;
}

export const DegreePathways: React.FC<DegreePathwaysProps> = memo(({ pathways, locale }) => {
  const { t } = useI18n();
  return (
    <div className="bg-black/20 backdrop-blur-lg border border-white/10 rounded-2xl p-6 shadow-lg">
      <div className="flex items-center mb-4">
        <BookOpenIcon className="w-7 h-7 text-fuchsia-400 mr-3 rtl:ml-3 rtl:mr-0" />
        <h3 className="text-xl font-bold text-fuchsia-400">{t.degreePathways.title}</h3>
      </div>
      <div className="space-y-6">
        {pathways.map((pathway, index) => (
          <DegreePathwayCard key={index} pathway={pathway} locale={locale} />
        ))}
      </div>
    </div>
  );
});