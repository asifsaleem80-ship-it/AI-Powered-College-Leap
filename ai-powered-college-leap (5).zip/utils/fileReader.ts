import type { FileData } from '../types';

interface FileReaderOptions {
  file: File;
  onProgress: (progress: number) => void;
  onLoad: (fileData: FileData) => void;
  onError: (errorMessage: string) => void;
  t: any; // Translation function object
}

const MAX_FILE_SIZE = 4 * 1024 * 1024; // 4MB
const ACCEPTED_FILE_TYPES = ['image/png', 'image/jpeg', 'application/pdf'];

function arrayBufferToBase64(buffer: ArrayBuffer): string {
  let binary = '';
  const bytes = new Uint8Array(buffer);
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return window.btoa(binary);
}


export function readFileWithProgress({ file, onProgress, onLoad, onError, t }: FileReaderOptions): void {
  if (file.size > MAX_FILE_SIZE) {
    onError(t.form.error.fileSize);
    return;
  }

  if (!ACCEPTED_FILE_TYPES.includes(file.type)) {
    onError(t.form.error.fileType);
    return;
  }

  const reader = new FileReader();

  reader.onprogress = (event) => {
    if (event.lengthComputable) {
      const progress = Math.round((event.loaded / event.total) * 100);
      onProgress(progress);
    }
  };

  reader.onloadend = () => {
    onProgress(100);
  };
  
  reader.onload = () => {
    if (reader.result) {
        const base64String = arrayBufferToBase64(reader.result as ArrayBuffer);
        onLoad({
            name: file.name,
            mimeType: file.type,
            base64: base64String,
        });
    } else {
        onError(t.form.error.fileRead);
    }
  };

  reader.onerror = () => {
    onError(t.form.error.fileReadError);
  };

  reader.onabort = () => {
    onError(t.form.error.fileReadAbort);
  };
  
  reader.readAsArrayBuffer(file);
}