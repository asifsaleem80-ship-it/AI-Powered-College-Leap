import { GoogleGenAI, Type, Modality } from "@google/genai";
import type { FileData, College, StudentAnalysis, CollegeDetails, CareerData, CareerPathDetails } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const scholarshipSchema = {
    type: Type.OBJECT,
    properties: {
        name: { type: Type.STRING, description: "Name of the scholarship" },
        description: { type: Type.STRING, description: "Brief description of the scholarship." },
        estimatedAmount: { type: Type.STRING, description: "Estimated grant amount (e.g., '$5,000/year', 'Full Tuition')." },
        eligibility: { type: Type.STRING, description: "Key eligibility criteria (e.g., 'Academic Merit', 'Financial Need')." },
        website: { type: Type.STRING, description: "A direct URL to the scholarship information page. If not available, this can be omitted." },
    },
    required: ['name', 'estimatedAmount', 'eligibility', 'description'],
};

const collegeSchema = {
  type: Type.ARRAY,
  items: {
    type: Type.OBJECT,
    properties: {
      name: { type: Type.STRING, description: "Name of the college" },
      website: { type: Type.STRING, description: "Official website URL" },
      reason: { type: Type.STRING, description: "Reason for recommendation" },
      estimatedTuitionLocal: { type: Type.STRING, description: "Estimated annual tuition for local/domestic students" },
      estimatedTuitionInternational: { type: Type.STRING, description: "Estimated annual tuition for international students" },
      scholarships: {
        type: Type.ARRAY,
        description: "A list of 2-3 relevant scholarship opportunities for the student. If none are found, return an empty array.",
        items: scholarshipSchema,
      },
    },
    required: ['name', 'website', 'reason', 'estimatedTuitionLocal', 'estimatedTuitionInternational', 'scholarships'],
  },
};

const studentAnalysisSchema = {
    type: Type.OBJECT,
    properties: {
        studentName: { type: Type.STRING, description: "The student's full name as found on the score report. If not found, this can be omitted." },
        summary: { type: Type.STRING, description: "A 2-3 paragraph summary highlighting the student's academic strengths and offering encouragement."},
        keyStrengths: {
            type: Type.ARRAY,
            description: "A bulleted list of 3-5 key academic strengths identified from the report.",
            items: { type: Type.STRING }
        },
        pathways: {
            type: Type.ARRAY,
            description: "A list of 3-4 potential degree pathways.",
            items: {
                type: Type.OBJECT,
                properties: {
                    name: { type: Type.STRING, description: "Name of the degree pathway (e.g., 'Computer Science & AI')." },
                    description: { type: Type.STRING, description: "A brief description of why this pathway is a good fit based on the score report." },
                    careerOptions: {
                        type: Type.ARRAY,
                        description: "A list of 3-4 potential career options for this pathway.",
                        items: { type: Type.STRING }
                    }
                },
                required: ['name', 'description', 'careerOptions']
            }
        }
    },
    required: ['summary', 'keyStrengths', 'pathways']
};

const collegeDetailsSchema = {
    type: Type.OBJECT,
    properties: {
        overview: { type: Type.STRING, description: "A one-paragraph overview of the university's mission, strengths, and campus atmosphere." },
        programHighlights: { type: Type.STRING, description: "A one-paragraph highlight of specific programs or departments relevant to the student's academic profile." },
        diversityAndCulture: { type: Type.STRING, description: "A one-paragraph description of the university's diversity, student body, and campus culture." },
        studentExperience: { type: Type.STRING, description: "A one-paragraph overview of student life, including clubs, activities, and campus traditions." },
        testimonials: {
            type: Type.ARRAY,
            description: "A list of 2 authentic-sounding student testimonials.",
            items: {
                type: Type.OBJECT,
                properties: {
                    quote: { type: Type.STRING, description: "A positive, insightful quote about the student experience." },
                    author: { type: Type.STRING, description: "The fictional student's name and major (e.g., 'Sarah, Computer Science Major')." }
                },
                required: ['quote', 'author']
            }
        },
        averageGpa: { type: Type.STRING, description: "The average GPA required for admission (e.g., '3.8 / 4.0'). If not found, this field can be omitted." },
        acceptanceRate: { type: Type.STRING, description: "The university's acceptance rate (e.g., '15%'). If not found, this field can be omitted." }
    },
    required: ['overview', 'programHighlights', 'diversityAndCulture', 'studentExperience', 'testimonials']
};

const careerDataSchema = {
  type: Type.OBJECT,
  properties: {
    jobMarketOverview: {
      type: Type.OBJECT,
      description: "Overview of the job market for this degree.",
      properties: {
        overallOutlook: { type: Type.STRING, description: "A paragraph on the job outlook." },
        growthRate: { type: Type.STRING, description: "A paragraph on projected growth rates, including specific percentages if available." },
        competitionLevel: { type: Type.STRING, description: "A paragraph describing the competition for jobs in this field." },
      },
      required: ['overallOutlook', 'growthRate', 'competitionLevel'],
    },
    careerPathCount: { type: Type.INTEGER, description: "Total number of distinct career paths available." },
    industryCount: { type: Type.INTEGER, description: "Total number of different industry sectors available." },
    averageSalaryRange: { type: Type.STRING, description: "Estimated average starting salary range, e.g., '$100,000-$150,000+'" },
    topCareerPaths: {
      type: Type.ARRAY,
      description: "A list of the top 2-4 career paths.",
      items: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING, description: "Job title of the career path." },
          description: { type: Type.STRING, description: "A paragraph describing the responsibilities and nature of this role." },
        },
        required: ['title', 'description'],
      },
    },
  },
  required: ['jobMarketOverview', 'careerPathCount', 'industryCount', 'averageSalaryRange', 'topCareerPaths'],
};

const careerPathDetailsSchema = {
    type: Type.OBJECT,
    properties: {
        dayToDayResponsibilities: {
            type: Type.ARRAY,
            description: "A list of 3-5 typical day-to-day responsibilities for this role.",
            items: { type: Type.STRING }
        },
        requiredSkills: {
            type: Type.ARRAY,
            description: "A list of 3-5 essential hard and soft skills for this role.",
            items: { type: Type.STRING }
        },
        careerProgression: {
            type: Type.STRING,
            description: "A one-paragraph description of the potential career progression path, including possible senior roles or specializations."
        }
    },
    required: ['dayToDayResponsibilities', 'requiredSkills', 'careerProgression']
};


export async function getStudentAnalysis(file: FileData, languageName: string): Promise<StudentAnalysis> {
    const model = 'gemini-2.5-pro';
    
    const imagePart = {
        inlineData: {
            mimeType: file.mimeType,
            data: file.base64,
        },
    };

    const textPart = {
        text: `
            You are an expert, encouraging college advisor for high school students (grades 8-12).
            Analyze the provided student score report. Your task is to provide a personalized analysis that is both insightful and motivational.

            Based on the score report, generate the following:
            1.  **studentName**: Extract the student's full name from the report. If it's not clearly visible, you can omit this field.
            2.  **summary**: A 2-3 paragraph summary. Start by highlighting the student's academic strengths as evidenced by their scores. Be specific if possible. End with an encouraging and motivational sentence to inspire them.
            3.  **keyStrengths**: A bulleted list of 3-5 of the student's key academic strengths, directly derived from the score report. These should be concise points.
            4.  **pathways**: Suggest 3-4 potential degree pathways that align with the student's strengths. For each pathway, provide:
                - name: The name of the degree pathway.
                - description: A brief explanation (1-2 sentences) of why this is a good fit.
                - careerOptions: A list of 3-4 potential career options.

            IMPORTANT: The user's selected language is ${languageName}. You MUST generate the entire response (summary, keyStrengths, and pathways, including career options) in ${languageName}.

            Return the response ONLY as a JSON object adhering to the provided schema. Do not include any other text, explanations, or markdown formatting.
        `
    };
    
    try {
        const response = await ai.models.generateContent({
            model: model,
            contents: { parts: [textPart, imagePart] },
            config: {
                responseMimeType: 'application/json',
                responseSchema: studentAnalysisSchema,
            },
        });

        const jsonText = response.text.trim();
        const analysis = JSON.parse(jsonText);
        return analysis as StudentAnalysis;

    } catch (error) {
        console.error("Error getting student analysis:", error);
        if (error instanceof Error) {
            throw new Error(`Failed to get student analysis from AI: ${error.message}`);
        }
        throw new Error("An unknown error occurred while analyzing the student report.");
    }
}


export async function analyzeScoreReport(
    file: FileData, 
    location: string, 
    degreeProgram: string, 
    universitySize: string,
    campusSetting: string,
    prioritizeRankings: boolean,
    wantsScholarship: boolean, 
    scholarshipTypes: string[],
    minGrantAmount: string,
    languageName: string
): Promise<College[]> {
  const model = "gemini-2.5-flash";

  const imagePart = {
    inlineData: {
      mimeType: file.mimeType,
      data: file.base64,
    },
  };
  
  const degreePromptPart = degreeProgram
    ? `The student is specifically interested in pursuing a degree in '${degreeProgram}'. Please prioritize colleges that have strong programs in this field.`
    : '';

  const locationPromptPart = location === 'Any / Undecided'
    ? 'Suggest 5 suitable colleges from anywhere in the world, ensuring a diverse geographical selection.'
    : `Suggest 5 suitable colleges in ${location}.`;

  const sizePromptPart = universitySize !== 'Any' 
    ? `The student prefers a university of this size: ${universitySize}.` 
    : '';

  const settingPromptPart = campusSetting !== 'Any'
    ? `The student prefers a university with a ${campusSetting.toLowerCase()} campus setting.`
    : '';
    
  const rankingsPromptPart = prioritizeRankings
    ? 'The student wants to prioritize universities with highly-ranked programs in their field of interest. Please factor this heavily into your suggestions.'
    : '';

  let scholarshipPromptPart = "";
    if (wantsScholarship) {
        let typesPrompt = scholarshipTypes.length > 0 ? `Prioritize the following types: ${scholarshipTypes.join(', ')}.` : '';
        let amountPrompt = minGrantAmount !== 'Any' ? `The student is hoping for a minimum grant amount of ${minGrantAmount}.` : '';

        scholarshipPromptPart = `
            Crucially, the student is looking for scholarship opportunities. For each college, you MUST research and find 2-3 relevant scholarships.
            ${typesPrompt}
            ${amountPrompt}
            For each scholarship, provide its name, a brief description, the estimated grant amount, key eligibility criteria, and a website URL.
            The 'website' field should contain a direct URL to the scholarship information page. If a direct link is not available, link to the university's main financial aid or scholarship portal. If no relevant link can be found at all, you may omit the 'website' property for that scholarship.
            If you cannot find any relevant scholarships that meet the criteria, you MUST return an empty array for the 'scholarships' field for that college.
        `;
    } else {
        scholarshipPromptPart = "The student has not requested scholarship information. You MUST return an empty array for the 'scholarships' field for every college.";
    }


  const textPart = {
    text: `
      You are an expert college admissions advisor for high school students (grades 8-12). Analyze the provided student score report.
      Based on the scores and subjects, ${locationPromptPart}
      
      Here are the student's preferences for their search:
      ${degreePromptPart}
      ${sizePromptPart}
      ${settingPromptPart}
      ${rankingsPromptPart}

      ${scholarshipPromptPart}

      For each college, provide:
      - name: The name of the college. This should remain in its original language and should NOT be translated.
      - website: A valid, complete URL to its official website.
      - reason: A brief explanation (2-3 sentences) why this college is a good fit for the student, referencing their likely strengths based on the scores and their stated preferences.
      - estimatedTuitionLocal: An estimated annual tuition fee for local/domestic students, in the local currency and USD, formatted like 'SGD 20,000 (~$15,000 USD)'.
      - estimatedTuitionInternational: An estimated annual tuition fee for international students, in the local currency and USD, formatted like 'SGD 40,000 (~$30,000 USD)'. If the fees are the same, repeat the value.
      - scholarships: An array of scholarship objects as described above, including a website link for each where possible.

      IMPORTANT: The user's selected language is ${languageName}. Generate all textual content (especially the 'reason' and all fields within 'scholarships') in ${languageName}.

      Return the response ONLY as a JSON array of objects. Do not include any other text, explanations, or markdown formatting.
    `,
  };

  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: { parts: [textPart, imagePart] },
      config: {
        responseMimeType: 'application/json',
        responseSchema: collegeSchema,
      },
    });

    const jsonText = response.text.trim();
    const colleges = JSON.parse(jsonText);
    return colleges as College[];

  } catch (error)
 {
    console.error("Error analyzing score report:", error);
    if (error instanceof Error) {
        throw new Error(`Failed to get suggestions from AI: ${error.message}`);
    }
    throw new Error("An unknown error occurred while analyzing the score report.");
  }
}

export async function getCollegeDetails(collegeName: string, studentSummary: string, languageName: string): Promise<CollegeDetails> {
    const model = 'gemini-2.5-flash';
    const schemaForPrompt = JSON.stringify(collegeDetailsSchema, null, 2);

    const prompt = `
        You are an expert college advisor with access to Google Search. Provide detailed information about ${collegeName} for a prospective student with the following profile: "${studentSummary}".
        
        Your primary task is to use Google Search to find up-to-date and accurate information. Generate the following content:
        
        - **averageGpa**: The average GPA required for admission (e.g., '3.8 / 4.0'). If this information is not readily available, omit this field.
        - **acceptanceRate**: The university's acceptance rate (e.g., '15%'). If this information is not readily available, omit this field.
        - **overview**: A one-paragraph overview of the university's mission, strengths, and campus atmosphere.
        - **programHighlights**: A one-paragraph highlight of specific programs or departments relevant to the student's academic profile.
        - **diversityAndCulture**: A one-paragraph description of the university's diversity, student body, and campus culture.
        - **studentExperience**: A one-paragraph overview of student life, including clubs, activities, and campus traditions.
        - **testimonials**: Create 2 authentic-sounding student testimonials. Each should be a positive, insightful quote about the student experience, authored by a fictional student with a relevant major.

        **CRITICAL INSTRUCTIONS:**
        1.  **LANGUAGE**: The user's selected language is ${languageName}. You MUST generate all textual content (descriptions, overviews, testimonials, etc.) in ${languageName}.
        2.  **JSON OUTPUT**: You MUST return your entire response as a single, valid JSON object. Do not include any other text, explanations, code block formatting (like \`\`\`json), or markdown.
        3.  **JSON VALIDITY**: Ensure the JSON is perfectly formed. Pay close attention to escaping characters. Any double quotes inside a string value must be escaped with a backslash (e.g., "a string with a \\"quote\\" inside").
        4.  **SCHEMA**: The JSON object must strictly adhere to the following structure:
            ${schemaForPrompt}
    `;
    let rawResponseText = '';
    try {
        const response = await ai.models.generateContent({
            model: model,
            contents: prompt,
            config: {
                tools: [{googleSearch: {}}],
            },
        });

        rawResponseText = response.text;
        let jsonText = rawResponseText.trim();
        if (jsonText.startsWith('```json')) {
            jsonText = jsonText.substring(7, jsonText.length - 3).trim();
        } else if (jsonText.startsWith('```')) {
             jsonText = jsonText.substring(3, jsonText.length - 3).trim();
        }

        return JSON.parse(jsonText) as CollegeDetails;
    } catch (error) {
        console.error(`Error getting details for ${collegeName}:`, error);
        if (error instanceof SyntaxError) {
            console.error("Failed to parse JSON response from AI:", rawResponseText);
            throw new Error(`The AI returned an invalid data format for college details.`);
       }
        throw new Error(`Failed to get college details from AI: ${error instanceof Error ? error.message : "Unknown error"}`);
    }
}

export async function askAboutCollege(collegeName: string, collegeDetails: CollegeDetails, studentSummary: string, question: string, languageName: string): Promise<string> {
    const model = 'gemini-2.5-flash';
    
    const context = `
        - University Overview: ${collegeDetails.overview}
        - Program Highlights: ${collegeDetails.programHighlights}
        - Diversity and Culture: ${collegeDetails.diversityAndCulture}
        - Student Experience: ${collegeDetails.studentExperience}
        - Student Testimonials: ${collegeDetails.testimonials.map(t => `"${t.quote}" - ${t.author}`).join(', ')}
    `;

    const prompt = `
        You are a helpful and concise college advisor. A student is asking a specific question about a college.
        
        **Student's Profile:**
        ${studentSummary}

        **Information you have about ${collegeName}:**
        ${context}

        **Student's Question:**
        "${question}"

        Based ONLY on the provided context, answer the student's question. If the information to answer the question is not in the context, politely state that you don't have that specific information. Keep your answer to 2-3 sentences.

        IMPORTANT: You MUST answer in ${languageName}.
    `;

    try {
        const response = await ai.models.generateContent({
            model: model,
            contents: prompt,
        });
        return response.text;
    } catch (error) {
        console.error(`Error asking about ${collegeName}:`, error);
        throw new Error(`Failed to get answer from AI: ${error instanceof Error ? error.message : "Unknown error"}`);
    }
}

export async function getCareerOpportunities(degreeName: string, languageName: string): Promise<CareerData> {
    const model = 'gemini-2.5-pro';
    const schemaForPrompt = JSON.stringify(careerDataSchema, null, 2);
    
    const prompt = `
        You are an expert career counselor for students. Your task is to provide a detailed overview of career opportunities for a student pursuing a degree in "${degreeName}".
        Use Google Search to find up-to-date information on the job market.
        
        Generate the following information:
        - jobMarketOverview: 
            - overallOutlook: A paragraph describing the overall job market outlook.
            - growthRate: A paragraph on the projected growth rate, citing specific percentages if found.
            - competitionLevel: A paragraph about the typical competition level for entry-level and advanced roles.
        - careerPathCount: A realistic integer representing the number of distinct career paths available.
        - industryCount: A realistic integer for the number of different industry sectors this degree is relevant to.
        - averageSalaryRange: A single string representing the estimated average starting salary range, e.g., "$100,000-$150,000+".
        - topCareerPaths: A list of 2 to 4 of the most common or promising career paths. For each:
            - title: The job title.
            - description: A paragraph describing the primary responsibilities and nature of the role.
            
        **CRITICAL INSTRUCTIONS:**
        1. **LANGUAGE**: The user's selected language is ${languageName}. You MUST generate all textual content in ${languageName}.
        2. **JSON OUTPUT**: Return a single, valid JSON object. Do not include any extra text, explanations, or markdown formatting like \`\`\`json.
        3. **JSON VALIDITY**: Ensure the JSON is perfectly formed. Pay close attention to escaping characters. Any double quotes within string values must be escaped with a backslash (e.g., "a string with a \\"quote\\" inside").
        4. **SCHEMA**: The JSON object must strictly adhere to the following schema:
        ${schemaForPrompt}
    `;
    let rawResponseText = '';
    try {
        const response = await ai.models.generateContent({
            model: model,
            contents: prompt,
            config: {
                tools: [{googleSearch: {}}],
            },
        });
        
        rawResponseText = response.text;
        let jsonText = rawResponseText.trim();
        if (jsonText.startsWith('```json')) {
            jsonText = jsonText.substring(7, jsonText.length - 3).trim();
        } else if (jsonText.startsWith('```')) {
             jsonText = jsonText.substring(3, jsonText.length - 3).trim();
        }
        return JSON.parse(jsonText) as CareerData;

    } catch (error) {
        console.error(`Error getting career opportunities for ${degreeName}:`, error);
         if (error instanceof SyntaxError) {
            console.error("Failed to parse JSON response from AI:", rawResponseText);
            throw new Error(`The AI returned an invalid data format for career data.`);
       }
        throw new Error(`Failed to get career data from AI: ${error instanceof Error ? error.message : "Unknown error"}`);
    }
}

export async function getCareerPathDetails(careerPathTitle: string, degreeName: string, languageName: string): Promise<CareerPathDetails> {
    const model = 'gemini-2.5-pro';
    const schemaForPrompt = JSON.stringify(careerPathDetailsSchema, null, 2);

    const prompt = `
        You are an expert career advisor. Provide detailed information about the career path "${careerPathTitle}" for a student with a degree in "${degreeName}".
        Use Google Search to find accurate, real-world information.

        Generate the following details:
        - dayToDayResponsibilities: A list of 3-5 bullet points describing typical day-to-day tasks and responsibilities.
        - requiredSkills: A list of 3-5 key hard and soft skills needed to succeed in this role.
        - careerProgression: A one-paragraph summary of the potential career path, including next steps, senior roles, or specialization opportunities.

        **CRITICAL INSTRUCTIONS:**
        1. **LANGUAGE**: The user's selected language is ${languageName}. You MUST generate all textual content in ${languageName}.
        2. **JSON OUTPUT**: Return a single, valid JSON object. Do not include any extra text, explanations, or markdown formatting like \`\`\`json.
        3. **JSON VALIDITY**: Ensure the JSON is perfectly formed. Pay close attention to escaping characters. Any double quotes within string values must be escaped with a backslash (e.g., "a string with a \\"quote\\" inside").
        4. **SCHEMA**: The JSON object must strictly adhere to the provided schema:
        ${schemaForPrompt}
    `;

    let rawResponseText = '';
    try {
        const response = await ai.models.generateContent({
            model: model,
            contents: prompt,
            config: {
                tools: [{googleSearch: {}}],
            },
        });

        rawResponseText = response.text;
        let jsonText = rawResponseText.trim();
        if (jsonText.startsWith('```json')) {
            jsonText = jsonText.substring(7, jsonText.length - 3).trim();
        } else if (jsonText.startsWith('```')) {
            jsonText = jsonText.substring(3, jsonText.length - 3).trim();
        }

        return JSON.parse(jsonText) as CareerPathDetails;
    } catch (error) {
        console.error(`Error getting career path details for ${careerPathTitle}:`, error);
        if (error instanceof SyntaxError) {
            console.error("Failed to parse JSON response from AI:", rawResponseText);
            throw new Error(`The AI returned an invalid data format for career path details.`);
        }
        if (error instanceof Error) {
            throw new Error(`Failed to get career path details from AI: ${error.message}`);
        }
        throw new Error("An unknown error occurred while getting career path details.");
    }
}

export async function generateSummaryVideo(
    studentName: string,
    summary: string,
    onProgress: (progressKey: 'initializing' | 'generating' | 'finalizing') => void
): Promise<string> {
    // Re-initialize the client to ensure the latest API key is used, as per Veo guidelines.
    const videoAI = new GoogleGenAI({ apiKey: API_KEY });

    const prompt = `Create a short, exciting 15-second CNN-style news report celebrating the academic success of a student named ${studentName}. The report should be professional, with a news anchor voiceover. It should highlight their key strengths based on this summary: "${summary}". Use dynamic graphics, an uplifting soundtrack, and a celebratory tone throughout the news segment.`;
    
    onProgress('initializing');

    let operation = await videoAI.models.generateVideos({
        model: 'veo-3.1-fast-generate-preview',
        prompt: prompt,
        config: {
            numberOfVideos: 1,
            resolution: '720p',
            aspectRatio: '16:9'
        }
    });

    onProgress('generating');

    while (!operation.done) {
        await new Promise(resolve => setTimeout(resolve, 10000));
        operation = await videoAI.operations.getVideosOperation({ operation: operation });
    }

    if (operation.error) {
        throw new Error(operation.error.message || "Video generation failed in operation.");
    }

    const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
    if (!downloadLink) {
        throw new Error("Video generation succeeded but no download link was provided.");
    }
    
    onProgress('finalizing');

    const response = await fetch(`${downloadLink}&key=${API_KEY}`);
    if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Failed to download video file: ${response.statusText} - ${errorText}`);
    }

    const videoBlob = await response.blob();
    return URL.createObjectURL(videoBlob);
}

export async function generateCoverImage(studentName: string): Promise<string> {
    const model = 'gemini-2.5-flash-image';
    
    const prompt = `Create a high-quality, realistic Time Magazine cover with the main title 'STUDENT OF THE YEAR'. The cover should prominently feature the name '${studentName}'. The image should depict an accomplished, confident, and diverse student looking towards the future. Use a classic, professional magazine cover layout.`;

    try {
        const response = await ai.models.generateContent({
            model: model,
            contents: {
                parts: [{ text: prompt }],
            },
            config: {
                responseModalities: [Modality.IMAGE],
            },
        });
        
        for (const part of response.candidates[0].content.parts) {
            if (part.inlineData) {
                return part.inlineData.data; // This is the base64 string
            }
        }
        throw new Error("No image data was found in the AI response.");
    } catch (error) {
        console.error("Error generating cover image:", error);
        if (error instanceof Error) {
            throw new Error(`Failed to generate cover image from AI: ${error.message}`);
        }
        throw new Error("An unknown error occurred while generating the cover image.");
    }
}